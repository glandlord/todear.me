<div id="sidebar-wrapper"><div id="sidebar">
        <div class="box sidebar-box">
            <div class="block-content">
                <?php include (TEMPLATEPATH . '/searchform.php'); ?>
            </div>
        </div>
        
        <div class="box sidebar-box">
		<ul>
            <li>
                <h2 class="block-title">Language</h2>
                <div class="block-content">
                    <ul class="lang-list">
                    <li><a class="lang-zh-cn" href="http://www.sxnsx.com/" title="shellex in chinese"></a></li>
                    <li><a class="lang-en-us" href="http://en.sxnsx.com/" title="shellex in english"></a></li>
                    </ul>                    
                </div>
			</li>

            <li>
                <h2 class="block-title">About</h2>
                <div class="block-content">
                    <p>Hi, 我是Shellex, 本站一万年以后将会兼容IE，敬请期待。</p>
                    <p>转载本博客文章请保留出处. 如果你喜欢我的博客，不妨点击下面的按钮<b>订阅</b>我</p>
                    <p>
                    <!-- Feedsky FEED 订阅统计发布代码开始 -->
                    <a href="http://feed.feedsky.com/Shellex" title="Shellex->blog here" target="_blank"><img src="http://www.feedsky.com/feed/Shellex/sc/gif" style="border:0" alt="" /></a>
                    <!-- Feedsky FEED 订阅统计发布代码结束 -->
                    <a href="http://feeds2.feedburner.com/shellex-cn"><img src="http://feeds2.feedburner.com/~fc/shellex-cn?bg=FF9900&amp;fg=444444&amp;anim=0" height="26" width="88" style="border:0" alt="" /></a></p>
                    <p><a href="http://www.sxnsx.com/subscribe_rss_to_tweak_yourself/">什么是“订阅”？</a></p>
                </div>
            </li>
        </ul>
        </div>

        <?php if ( function_exists('recent_comments') ) { ?>
        <div class="box sidebar-box">
                <h2 class="block-title">最近的评论</h2>
                <div class="block-content">
                    <?php recent_comments(); ?>

                </div>
        </div>
        <?php } ?>

        <?php if ( function_exists('random_posts') ) { ?>
        <div class="box sidebar-box">
                <h2 class="block-title">随便看看</h2>
                <div class="block-content">
                    <?php random_posts('title=&'); ?>
                </div>
        </div>
        <?php } ?>

        <?php if ( function_exists('twitter_messages') ) { ?>
        <div class="box sidebar-box">
                <h2 class="block-title"><a href="http://twitter.com/shellex">Shellex在叽叽喳喳</a></h2>
                <div class="block-content">
                    <?php twitter_messages("shellex", 7, true, false, '#', true, true, false); ?>
                </div>
        </div>
        <?php } ?>

        <?php if ( function_exists('wp_list_bookmarks') ) { ?>
        <div class="box sidebar-box">
                <h2 class="block-title">Blogroll</h2>
                <div class="block-content">
                   <ul>
                      <?php wp_list_bookmarks('title_li=&categorize=0&show_description=1'); ?>
                   </ul>
                </div>
        </div>
        <?php } ?>

        <div class="box sidebar-box">
        <ul>
            <li>
                <h2 class="block-title">Meta</h2>
                <div class="block-content">
                    <ul>
                        <?php wp_register(); ?>
                        <li><?php wp_loginout(); ?></li>
                        <li>点击: <?php get_totalviews(true,false,true); ?></li>
                        <li>文章: <?php echo wp_count_posts('post')->publish; ?></li>
                        <li>评论: <?php $total_cmts=get_comment_count(); echo $total_cmts['approved']; ?></li>
                    </ul>

                </div>
            </li>

            <?php if(get_option('backlinks_key')) {?>
                <li><h2 class="block-title">Partner links</h2>
                    <div class="block-content">
                        <?php backlinks_links()?>
                        <?php
// THE FOLLOWING BLOCK IS USED TO RETRIEVE AND DISPLAY LINK INFORMATION.
// PLACE THIS ENTIRE BLOCK IN THE AREA YOU WANT THE DATA TO BE DISPLAYED.

// MODIFY THE VARIABLES BELOW:
// The following variable defines whether links are opened in a new window
// (1 = Yes, 0 = No)
$OpenInNewWindow = "1";

// # DO NOT MODIFY ANYTHING ELSE BELOW THIS LINE!
// ----------------------------------------------
$BLKey = "4JZ1-6F91-7Q4Y";

$QueryString  = "LinkUrl=".urlencode((($_SERVER['HTTPS']=='on')?'https://':'http://').$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
$QueryString .= "&Key=" .urlencode($BLKey);
$QueryString .= "&OpenInNewWindow=" .urlencode($OpenInNewWindow);


if(intval(get_cfg_var('allow_url_fopen')) && function_exists('readfile')) {
    @readfile("http://brokerage.linkadage.com/engine.php?".$QueryString); 
}
elseif(intval(get_cfg_var('allow_url_fopen')) && function_exists('file')) {
    if($content = @file("http://brokerage.linkadage.com/engine.php?".$QueryString)) 
        print @join('', $content);
}
elseif(function_exists('curl_init')) {
    $ch = curl_init ("http://brokerage.linkadage.com/engine.php?".$QueryString);
    curl_setopt ($ch, CURLOPT_HEADER, 0);
    curl_exec ($ch);

    if(curl_error($ch))
        print "Error processing request";

    curl_close ($ch);
}
else {
    print "It appears that your web host has disabled all functions for handling remote pages and as a result the BackLinks software will not function on your web page. Please contact your web host for more information.";
}
?>


<P><A HREF="http://www.backlinks.com/aff/35908" target="_blank">
<IMG SRC="http://www.backlinks.com/images/125X125.jpg" BORDER="0" WIDTH="125" HEIGHT="125" ALT="make money with your web site">
</IMG>
</A></P>
                    </div>
                </li>
            <?php } ?>
        </ul>
        </div> <!--box-->

        <div class="box sidebar-box">
        <ul>
            <li>
                <h2 class="block-title">Certifies</h2>
                <div class="block-content">
                    <table border="0" cellpadding="0">
                    <tr><td><a class="button-xhtml clearfix" href="http://validator.w3.org/check?uri=http%3A%2F%2Fwww.sxnsx.com%2F" title="W3C XHTML 1.1 Pass"></a></td>
                        <td><a class="button-css clearfix" href="http://jigsaw.w3.org/css-validator/" title="W3C CSS validator Pass" ></a></td>
                    </tr>

                    <tr><td><a class="button-cc clearfix" rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.5/cn/" title="Creative Commons Licenses BY-NC-SA"></a></td>
                        <td><a class="button-icp clearfix" href="http://www.miibeian.gov.cn" title="吉ICP备"></a></td>
                    </tr>

                    </table>
                </div>
            </li>

            <li>
                <h2 class="block-title">Support</h2>
                <div class="block-content">
                    <table border="0" cellpadding="0">
                    <tr><td><a class="button-gimp clearfix" href="http://www.gimp.org" title="Power By GIMP Image Editor" ></a></td>
                        <td><a class="button-inkscape clearfix"  href="http://www.inkscape.org/" title="Power By Inkscape Vector Graphics Editor"></a></td>
                    </tr>

                    <tr><td><a class="button-vim clearfix" href="http://www.vim.org" title="Power By VIM"></a></td>
                        <td><a class="button-firefox clearfix" href="http://www.mozilla.com/firefox?from=sfx&amp;uid=0&amp;t=315" title="Firefox  Capable"></a></td>
                    </tr>

                    <tr><td><a class="button-seal-script-wp  clearfix" href="http://www.sxnsx.com/seal-script-wp-theme/" title="Seal Script Wordpress Theme"></a></td>
                    <td><a class="button-ubuntu clearfix" href="http://www.ubuntu.com/" title="Power By Ubuntu Linux"></a></td>

                    </tr>

                    </table>
                </div>
            </li>

		</ul>
        </div> <!--box-->

    </div>
</div>



<?php get_header(); ?>

    <div id="content" class="box">
    
    <?php if (have_posts()) : ?>

        <?php while (have_posts()) : the_post(); ?>
            <div class="post" id="post-<?php the_ID(); ?>">
                <div class="post-title-wrapper">
                <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>

                <div class="post-meta-wrapper metastyle">
                <small>Post in <?php the_category(', ') ?> in <?php the_time('M jS, Y') ?>, VIEWs: <?php the_user_views("", true); ?>
</small>
                </div>
                </div>
                <div class="entry-wrapper">
				<div class="entry">
				<?php if (is_search()) { ?>
					<?php the_excerpt() ?>
				<?php } else { ?>
				    <?php if(!is_single()) {
		       		        the_excerpt();
		       		      } else {
		       			    the_content();
		       		} ?>
                    <br/>
					<a href="<?php the_permalink(); ?>">&#187&#187</a><br/><br/>
				<?php } ?>
				</div>
                <div class="postmeta">
                    <div class="label_base label_comments">
                    <?php comments_popup_link('% Comments &#187;'); ?>
                    </div>
                    <div class="label_base label_tags">TAGS</div> <?php the_tags('', ', ', ''); ?>
                    
                </div>

                </div>
			</div>

		<?php endwhile; ?>

        <?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); ?>
        <?php } else { ?>
            <div class="navigation">
                <div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
                <div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
            </div>
        <?php } ?> 
	<?php else : ?>

		<h2 class="center">Not Found</h2>
        <p class="center">Sorry, but you are looking for something that isn't here.</p>
		<?php include (TEMPLATEPATH . "/searchform.php"); ?>

	<?php endif; ?>

    </div>

    <?php get_sidebar(); ?>
</div>


<?php get_footer(); ?>



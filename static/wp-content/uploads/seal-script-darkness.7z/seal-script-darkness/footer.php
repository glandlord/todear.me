<div id="footer" class="clearfix">
    <div id="search_engine_box" style="display:none">
    <h2>您正在搜索 <span id="search_keywords"></span></h2>
        <div>关键字已在页面上高亮显示
        <a onclick="$('#search_engine_box').hide();return false;" href="#">[ 关闭 ]</a>
        </div>
    </div>
    
    <?php wp_footer(); ?>

    <!--google analytics -->
    <script type="text/javascript">
        var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
        document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
        </script>
        <script type="text/javascript">
        try {
        var pageTracker = _gat._getTracker("UA-4178606-4");
        pageTracker._trackPageview();
        } catch(err) {}
    </script>
    
    <!-- search engine recognisor -->
    <script type="text/javascript">
        <!--
        function checkURL(url,Knum){
         var reHost = /[\w]+:\/\/[\w\.]+\//; 

         var arrdata=(reHost.test(url))?((url.match(reHost)[0].indexOf("google")>0)?(url.match(/q=[\w+%]+/)[0].split(/=/)[1].match(/[^\+]+/g)):(null)):(null)

         Knum=(arrdata)?((Knum)?((Knum<arrdata.length)?(Knum):(arrdata.length)):(3)):(null);
         if(!Knum) return [];
         var arrKey=new Array();
         for(var i=0;i<Knum;i++){
         arrKey[i]=decodeURIComponent(arrdata[i]);
         }

         return arrKey; 
         }

        function HighlightText(obj,keyword,Kstyle)  
        {   
            if(Kstyle)  
            {  
                if (keyword.length != 0) {
                   $('#search_engine_box').show();
                }
                $('#search_keywords').html(keyword.join(','))
                var data=obj.html();  
                for(var i=0;i<keyword.length;i++){  
                    var reg = new RegExp(keyword[i]+"(?=[^<>]*<)","ig");  
                    data=data.replace(reg,'<span style="'+Kstyle+'">'+keyword[i]+'</span>')
                }  
                //don't work with jquery $()... WTF?
                document.getElementById('out-wrapper').innerHTML = data;
            }  
        }  
        function Highlightmain(){  
            if(!document.referrer)return;  
            HighlightText($('#out-wrapper'),checkURL(document.referrer,5),"background-color:#FFFF00; color:#000");  

        }  

        window.onload=function(){Highlightmain()};  
        -->
    </script>

    <p>
        * My blog is proudly powered by <a href="http://wordpress.org/">WordPress</a> and <a href="http://www.sxnsx.com/seal-script-darkness/">Seal-Script-Dark(ness)</a> theme.
        * <a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a>
        and <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a>.
        * <?php echo get_num_queries(); ?> queries cost <?php timer_stop(1); ?> seconds. 
    </p>

</div> <!--foot-->

</div> <!--out-wrapper-->
<script type="text/javascript">$('#sx-loading').hide();</script>
</body>
</html>


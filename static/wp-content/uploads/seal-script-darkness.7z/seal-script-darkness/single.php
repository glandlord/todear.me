<?php get_header(); ?>


    <div id="content" class="box">

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div class="navigation">
			<div class="alignright">下一篇：『<?php next_post_link('%link &raquo;') ?>』</div>
			<div class="alignleft">上一篇：『<?php previous_post_link('&laquo; %link') ?>』</div>
		</div>

        <div class="post" id="post-<?php the_ID(); ?>">
            <div class="post-title-wrapper">
                <h2><a href="#"><?php the_title(); ?></a></h2>

                <div class="post-meta-wrapper">
                <small>Post in <?php the_category(', ') ?> at <?php the_time('M jS, Y') ?>, VIEWs: <?php the_user_views("", true); ?>
                </small>
                </div>
            </div>
            
            <div class="entry-wrapper">
            <div class="entry">
                <div class="post-nav-mini">
                    <div class="clearfix" style="padding-left:20px;">
                        <h2>您可能也对这些感兴趣</h2>
                    </div>
                    <?php if ( function_exists('random_posts') ) { ?>
                        <?php st_related_posts('number=10&title=&include_page=false&xformat=<a href="%permalink%" title="%title% (%date%)">%title%</a>'); ?>
                    <?php } ?>
                </div>

				<?php the_content(); ?>

                <div class="postmeta">
                    <div class="label_base label_comments">
                        <a href="#respond">我要发言</a>
                    </div>
                    <div class="label_base label_license">
                        <a href="http://www.sxnsx.com/copyright-cc/">署名 • 非商业性使用 • 相同方式共享</a>
                    </div>
                    <div class="label_base label_tags">TAGS</div> <?php the_tags('', ', ', ''); ?>
                    
                </div>
                <?php edit_post_link('Edit','','.'); ?>
            </div>
            <?php wp_link_pages(); ?>
            </div>
		</div>

	<?php comments_template(); ?>

	<?php endwhile; else: ?>
            
        <h2 class="center">Not Found</h2>
		<p>Sorry, no posts matched your criteria.</p>
	    <?php comments_template(); ?>

    <?php endif; ?>
    </div>
    <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>


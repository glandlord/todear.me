<?php get_header(); ?>


    <div id="content" class="box">

        <h2 class="center">This page was not found on this Server</h2>
        <h2 class="center">You can try to search</h2>
		<?php include (TEMPLATEPATH . '/searchform.php'); ?>


    </div>
    <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>


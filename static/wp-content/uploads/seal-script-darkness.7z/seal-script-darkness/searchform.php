
<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
    <!--<label class="hidden" for="s"><?//php _e('Search for:'); ?></label>-->
    <div id="search-wrapper" class="box">
    <p>
<!-- value="<?//php the_search_query(); ?>" -->
    <input type="text"  name="s" id="s" onblur="if (this.value == '') {this.value = '输入搜索内容';}" onfocus="if (this.value == '输入搜索内容') {this.value = '';}" value="输入搜索内容"/> 
    <input type="submit" id="searchsubmit" value="Search"></input>
    </p>
    </div>
</form>

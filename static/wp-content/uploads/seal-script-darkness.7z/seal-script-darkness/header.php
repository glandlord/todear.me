<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="MSSmartTagsPreventParsing" content="true" />
<meta name="generator" content="gVim" />
<meta name="keywords" content="Linux, Shellex, Hacker, Python, Design, 安全"/>

<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>
<link rel="shortcut icon" type="image/png" href="<?php bloginfo('stylesheet_directory');?>/imgs/favicon.ico" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<!--[if lte IE 6]>
    <style type="text/css" media="all">
    @import "<?php bloginfo('stylesheet_directory');?>/ie_suck.css";
    </style>
<![endif]-->

<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url');?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<script type="text/javascript" src="<?php bloginfo('stylesheet_directory');?>/js/jquery.js" ></script>


<?php wp_head(); ?>
</head>
<body>
<div id="out-wrapper">
<div id="container" class="container">

<div id='sx-loading'>正在加载...</div>

<h1 class="blog-title"><a href="http://www.sxnsx.com/"><span>Shellex Blog Here</span></a></h1>

<div id="page-nav">
    <ul id="page-nav-lava">
    <li><a href="/">Home</a></li>
    <li><a href="/linux-toys">Linux Toys</a></li>
    <li><a href="/tags">Tags Cloud</a></li>
    <li><a href="/about">About</a></li>
    </ul>
</div>
<div class="clearfix"></div>



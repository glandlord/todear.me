<?php get_header(); ?>


    <div id="content" class="box">
    
    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
            <div class="post" id="post-<?php the_ID(); ?>">
                <div class="post-title-wrapper">
                    <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                    <div class="post-meta-wrapper">
                    <small>Post at <?php the_time('M jS, Y') ?>, VIEWs: <?php the_user_views("", true); ?>
                    </small>
                    </div>
                </div>

                <div class="entry-wrapper">
				<div class="entry">
					<?php the_content(); ?>
				</div>

                <div class="postmeta">
                    <div class="label_base label_comments">
                        <a href="#respond">我要发言</a>
                    </div>
                    <div class="label_base label_license">
                        <a href="http://www.sxnsx.com/copyright-cc/">署名 • 非商业性使用 • 相同方式共享</a>
                    </div>
                    <div class="label_base label_tags">TAGS</div> <?php the_tags('', ', ', ''); ?>
                    
                </div>
                <?php edit_post_link('Edit','','.'); ?>
                </div>
			</div>


	    <?php comments_template(); ?>
		<?php endwhile; else: ?>

            <h2 class="center">Not Found</h2>
            <p class="center">Sorry, but you are looking for something that isn't here.</p>
            <?php include (TEMPLATEPATH . "/searchform.php"); ?>

	<?php endif; ?>
    </div>
    <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>

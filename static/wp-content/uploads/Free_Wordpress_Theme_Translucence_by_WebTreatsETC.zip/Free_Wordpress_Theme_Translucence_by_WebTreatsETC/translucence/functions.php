<?php
$themename = "Translucence";
$shortname = "trans";


/* Get Stylesheets into a drop-down list */
$styles = array();
if(is_dir(TEMPLATEPATH . "/styles/")) {
	if($open_dirs = opendir(TEMPLATEPATH . "/styles/")) {
		while(($style = readdir($open_dirs)) !== false) {
			if(stristr($style, ".css") !== false) {
				$styles[] = $style;
			}
		}
	}
}
$style_dropdown = array_unshift($styles, "Choose a background style scheme:");


/* Translucence Admin Options*/
$options = array (

	array(	"name" => "Design",
		"type" => "title"),
	
	array(	"type" => "open"),
	
	array(	"name" => "Website Background",
		"desc" => "Which background style would you like?",
		"id" => $shortname."_colourscheme",
		"type" => "select",
		"std" => "Choose a background style scheme:",
		"options" => $styles),
		
	array(	"name" => "Disable/Enable Logo",
		"desc" => "Check to disable or uncheck to enable the Logo.<br />NOTE: If Logo is disabled the defualt 'Blog title' and 'Tagline' will show.",
		"id" => $shortname."_logo_disable",
		"type" => "checkbox"),
		
	array(	"name" => "Custom Logo",
		"desc" => "Paste the full URL of your custom logo image, should you wish to replace our default logo e.g. 'http://www.yoursite.com/logo.png'.<br />NOTE: The Logo should be a transparent .PNG to display correctly.",
		"id" => $shortname."_custom_logo",
		"type" => "text"),
	
	array(	"type" => "close"),
	
	array(	"name" => "Social Bookmarking",
		"type" => "title"),
	
	array(	"type" => "open"),
	
	array(	"name" => "Disable/Enable RSS Icon",
		"desc" => "Check to disable or uncheck to enable the RSS Icon.",
		"id" => $shortname."_rss_disable",
		"type" => "checkbox"),
		
	array(	"name" => "Feedburner RSS URL",
		"desc" => "Enter your Feedburner URL here.",
		"id" => $shortname."_feedburner_url",
		"type" => "text"),
				
	array(	"name" => "Disable/Enable Subscribe by Email Icon",
		"desc" => "Check to disable or uncheck to enable the Subscribe by Email Icon.",
		"id" => $shortname."_email_disable",
		"type" => "checkbox"),

	array(	"name" => "Feedburner RSS ID",
		"desc" => "Enter your Feedburner RSS ID here.",
		"id" => $shortname."_feedburner_username",
		"type" => "text"),
				
	array(	"name" => "Disable/Enable Twitter Icon",
		"desc" => "Check to disable or uncheck to enable the Twitter Icon.",
		"id" => $shortname."_twitter_disable",
		"type" => "checkbox"),

	array(	"name" => "Twitter Username",
		"desc" => "Enter your Twitter username here.",
		"id" => $shortname."_twitter_username",
		"type" => "text"),
				
	array(	"name" => "Disable/Enable Facebook Icon",
		"desc" => "Check to disable or uncheck to enable the Facebook Icon.",
		"id" => $shortname."_facebook_disable",
		"type" => "checkbox"),

	array(	"name" => "Facebook Username",
		"desc" => "Enter your Facebook username here.",
		"id" => $shortname."_facebook_username",
		"type" => "text"),
		
	array(	"type" => "close"),
		
	array(	"name" => "Google Analytics",
		"type" => "title"),
	
	array(	"type" => "open"),	
	
	array(	"name" => "Google Analytics",
		"desc" => "Insert your Google Analytics (or other) code here.",
		"id" => $shortname."_analytics_code",
		"type" => "textarea"),
		
	array(	"type" => "close")

);


function translucence_add_admin() {
global $themename, $shortname, $options;
if ( $_GET['page'] == basename(__FILE__) ) {
if ( 'save' == $_REQUEST['action'] ) {
	foreach ($options as $value) {
		update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }
	foreach ($options as $value) {
		if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }
		header("Location: themes.php?page=functions.php&saved=true");
	die;
		} else if( 'reset' == $_REQUEST['action'] ) {
	foreach ($options as $value) {
		delete_option( $value['id'] ); }
		header("Location: themes.php?page=functions.php&reset=true");
	die;
	}
}

if(!function_exists('wp_list_comments')) {
	add_theme_page($themename." Options", $themename, 'edit_themes', basename(__FILE__), 'translucence_admin');
		} else {
	add_menu_page($themename." Options", $themename, 'edit_themes', basename(__FILE__), 'translucence_admin');
	}
}


function translucence_admin() {
global $themename, $shortname, $options;
if ( $_REQUEST['saved'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings saved.</strong></p></div>';
if ( $_REQUEST['reset'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings reset.</strong></p></div>';
?>
<div class="wrap">
<h2><?php echo $themename; ?> settings</h2>
<form method="post">


<?php foreach ($options as $value) { 
switch ( $value['type'] ) {

case "open": ?>
<table width="100%" border="0" style="background-color:#F1F1F1; border:1px solid #E3E3E3; border-top:none; padding:10px;"><?php

break;
case "close":
?>
</table><br /><?php

break;
case "title":
?>
<table width="100%" border="0" style="background-color:#6D6D6D; border: 1px solid #E3E3E3; padding:5px 10px;">
<tr>
<td colspan="2">
<h3 style="color:#fff; font-family:Georgia,'Times New Roman',Times,serif; font-weight: bold;"><?php echo $value['name']; ?></h3>
</td>
</tr>
</table><?php

break;
case 'text':
?>
<tr>
<td width="20%" rowspan="2" valign="middle"><strong><?php echo $value['name']; ?></strong></td>
<td width="80%"><input style="width:400px;" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo get_settings( $value['id'] ); } else { echo $value['std']; } ?>" /></td>
</tr>
<tr>
<td><small><?php echo $value['desc']; ?></small></td>
</tr><tr><td colspan="2" style="margin-bottom:5px;border-bottom:1px dotted #C8C8C8;">&nbsp;</td></tr><tr><td colspan="2">&nbsp;</td></tr>
<?php 

break;
case 'textarea':
?>
<tr>
<td width="20%" rowspan="2" valign="middle"><strong><?php echo $value['name']; ?></strong></td>
<td width="80%"><textarea name="<?php echo $value['id']; ?>" style="width:400px; height:200px;" type="<?php echo $value['type']; ?>" cols="" rows=""><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings( $value['id'] )); } else { echo $value['std']; } ?></textarea></td>
</tr>
<tr>
<td><small><?php echo $value['desc']; ?></small></td>
</tr><tr><td colspan="2" style="margin-bottom:5px;border-bottom:1px dotted #C8C8C8;">&nbsp;</td></tr><tr><td colspan="2">&nbsp;</td></tr>
<?php 

break;
case 'select':
?>
<tr>
<td width="20%" rowspan="2" valign="middle"><strong><?php echo $value['name']; ?></strong></td>
<td width="80%"><select style="width:240px;" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>"><?php foreach ($value['options'] as $option) { ?><option<?php if ( get_settings( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>><?php echo $option; ?></option><?php } ?></select></td>
</tr>
<tr>
<td><small><?php echo $value['desc']; ?></small></td>
</tr><tr><td colspan="2" style="margin-bottom:5px;border-bottom:1px dotted #C8C8C8;">&nbsp;</td></tr><tr><td colspan="2">&nbsp;</td></tr>
<?php

break;
case "checkbox":
?>
<tr>
<td width="20%" rowspan="2" valign="middle"><strong><?php echo $value['name']; ?></strong></td>
<td width="80%"><? if(get_settings($value['id'])){ $checked = "checked=\"checked\""; }else{ $checked = ""; } ?>
<input type="checkbox" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="true" <?php echo $checked; ?> />
</td>
</tr>
<tr>
<td><small><?php echo $value['desc']; ?></small></td>
</tr><tr><td colspan="2" style="margin-bottom:5px;border-bottom:1px dotted #C8C8C8;">&nbsp;</td></tr><tr><td colspan="2">&nbsp;</td></tr>
<?php

break;
} 
}
?>
<p class="submit">
<input name="save" type="submit" value="Save changes" /> 
<input type="hidden" name="action" value="save" />
</p>
</form>
<form method="post">
<p class="submit">
<input name="reset" type="submit" value="Reset" />
<input type="hidden" name="action" value="reset" />
</p>
</form>
<?php
}
add_action('admin_menu', 'translucence_add_admin');

require(TEMPLATEPATH . "/var.php");


//Enable Sidebar
if ( function_exists('register_sidebar') ) {    
    register_sidebar(array(
		'name' => 'Sidebar',
		'before_widget' => '<div class="mysite_widget_divider"><div class="mysite_widget">',
		'after_widget' => '</div></div>',
		'before_title' => '<h4>',
		'after_title' => '</h4>',
	));
}

// If using 2.6 or below, use legacy comments display
add_filter( 'comments_template', 'legacy_comments' );
function legacy_comments( $file ) {
    if ( !function_exists('wp_list_comments') )
        $file = TEMPLATEPATH . '/comments.legacy.php';
    return $file;
}

?>
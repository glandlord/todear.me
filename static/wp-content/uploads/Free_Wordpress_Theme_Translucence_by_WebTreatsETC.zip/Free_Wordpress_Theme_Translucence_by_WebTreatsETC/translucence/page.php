<?php get_header(); ?>

<?php if(have_posts()) : while(have_posts()) : the_post(); ?>

<div <?php post_class() ?> id="post-<?php the_ID(); ?>">

	<h1 class="page_title"><?php the_title(); ?></h1>							

	<div class="entry">
		<?php the_content(); ?>
	</div>
	
<?php wp_link_pages('before=<div id="page-links">Pages: &after=</div>'); ?>

</div> <!-- .post -->

<div id="comments">
	<?php comments_template(); ?>
</div>

<?php endwhile; endif; ?>
	
<?php get_sidebar(); ?>
<?php get_footer(); ?>
<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="post" id="post_id_<?php the_ID(); ?>">		
	<h2 class="blog_h2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>		
	<div class="top_metadata">
		<div class="comment_count">
			<?php comments_popup_link('no comments', '1 comment', '% comments'); ?>
		</div>
		<div class="date_author">
			Posted on <?php the_time('M') ?> <?php the_time('j') ?> <?php the_time('Y') ?> by <?php the_author_posts_link(); ?> 
		</div>	
	</div>			
	<div class="entry">
		<?php the_content(); ?>
	</div>
	<?php wp_link_pages('before=<div id="page-links">Pages: &after=</div>'); ?>
			
	<br class="clearboth" />
	<div class="bottom_metadata">
		<span class="tags">
		<?php the_tags('&nbsp;&nbsp;<strong>Tags</strong>: <em>', '</em>, <em>', '</em>'); ?>
		</span>		
		<?php if ( count(($categories=get_the_category())) > 1 || $categories[0]->cat_ID != 1 ) : ?>
		 <strong>Category:</strong> 
		 <?php the_category(', ') ?>
		<?php endif; ?>
		<?php edit_post_link('Edit', '&nbsp;&nbsp;(&nbsp;&nbsp;', '&nbsp;&nbsp;)&nbsp;&nbsp;'); ?>
	</div>				
</div> <!-- post -->

<div id="comments">
	<?php comments_template(); ?>
</div>

<?php endwhile; else : ?>
	
	<p>Sorry, no posts matched your criteria.</p>

<?php endif; ?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
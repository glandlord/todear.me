<?php
/*
Template Name: Sitemap Template
*/
?>

<?php get_header(); ?>
<div <?php post_class() ?> id="post-<?php the_ID(); ?>">

	<h2><?php the_title(); ?></h2>
	<?php include(TEMPLATEPATH.'/sitemap-content.php'); ?>

</div> <!-- .post -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
<?php get_header(); ?>

<div <?php post_class() ?> id="post-404">
	
	<h2>Page Not Found</h2>

	<p>Looks like the page you're looking for isn't here anymore. Try using the search box or sitemap below.</p>

	<?php include(TEMPLATEPATH.'/searchform.php'); ?>
	<?php include(TEMPLATEPATH.'/sitemap-content.php'); ?>
	
</div> <!-- .post -->
	
<?php get_sidebar(); ?>
<?php get_footer(); ?>
	</div><!-- content -->
</div><!-- primary -->

<div id="secondary">
	<div class="content">
		<?php dynamic_sidebar('Sidebar') ?>
	</div><!-- content -->
</div><!-- secondary -->
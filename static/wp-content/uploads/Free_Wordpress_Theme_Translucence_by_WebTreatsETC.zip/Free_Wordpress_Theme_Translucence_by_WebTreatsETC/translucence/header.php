<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />

<!-- Get Background Image Style Sheet -->
<?php
require(TEMPLATEPATH . "/var.php");

if($trans_colourscheme) {
	if($trans_colourscheme == "Choose a background style scheme:") { ?>
		<link rel="stylesheet" type="text/css" media="all"
		href="<?php bloginfo('template_directory'); ?>/styles/lights.css" /><?php
	} else { ?>
		<link rel="stylesheet" type="text/css" media="all"
		href="<?php bloginfo('template_directory'); ?>/styles/<?php echo $trans_colourscheme; ?>" /><?php
	}
} else { ?>
	<link rel="stylesheet" type="text/css" media="all"
	href="<?php bloginfo('template_directory'); ?>/styles/lights.css" /><?php
} ?>

<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php wp_enqueue_script('jquery'); ?>
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>	

<!--[if IE 6]>
<script src="<?php bloginfo('template_directory'); ?>/inc/DD_belatedPNG_0.0.8a-min.js"></script>
<script>
    DD_belatedPNG.fix('#logo_img, #bg_header, #inner_body_block_head, #body_block, .mysite_widget_divider, #inner_body_block_foot, .header_socials img, #s');
</script>
<![endif]-->

</head>

<body class="alignC sidebar_1R">
	<div id="bg_middle">
		<div id="bg_header">
			<div id="bg_footer">
<div id="container">
	<div id="header">
		<div id="inner_header">

	<!-- Logo -->
	<?php if( (!$trans_custom_logo) && (!$trans_logo_disable) ) { ?>
			<div id="logo"><a href="<?php echo get_option('home'); ?>/"><img id="logo_img" alt="<?php echo get_option('home'); ?>/" src="<?php bloginfo( 'template_directory' ); ?>/images/logo.png"/></a></div>
	<?php } if( ($trans_custom_logo) && (!$trans_logo_disable) ) { ?>
			<div id="logo"><a href="<?php echo get_option('home'); ?>/"><img id="logo_img" alt="<?php echo get_option('home'); ?>/" src="<?php echo $trans_custom_logo; ?>"/></a></div>
	<?php } if ($trans_logo_disable) { ?>
			<div id="site_name"><a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a></div>
			<div id="tag_line"><?php bloginfo('description'); ?></div>
	<?php } ?>

<!-- Social Media Icon-->
<div id="social_media">
	<!-- RSS Icon-->
	<?php if( (!$trans_feedburner_url) && (!$trans_rss_disable) ) { ?>
			<div class="header_socials"><a href="<?php echo get_bloginfo_rss('rss2_url'); ?>"><img alt="rss" src="<?php bloginfo( 'template_directory' ); ?>/images/rss.png"/></a></div>
	<?php } if( ($trans_feedburner_url) && (!$trans_rss_disable) ) { ?>
			<div class="header_socials"><a href="<?php echo $trans_feedburner_url; ?>"><img alt="rss" src="<?php bloginfo( 'template_directory' ); ?>/images/rss.png"/></a></div>
	<?php } if ($trans_rss_disable) { 
			// RSS Icon Disabled
	 	  } ?>
	
	<!-- Email Icon-->
	<?php if( (!$trans_feedburner_username) && (!$trans_email_disable) ) { ?>
			<div class="header_socials"><a href="http://feedburner.google.com/fb/a/mailverify?uri="><img alt="email" src="<?php bloginfo( 'template_directory' ); ?>/images/email.png"/></a></div>
	<?php } if( ($trans_feedburner_username) && (!$trans_email_disable) ) { ?>
			<div class="header_socials"><a href="http://feedburner.google.com/fb/a/mailverify?uri=<?php echo $trans_feedburner_username; ?>"><img alt="email" src="<?php bloginfo( 'template_directory' ); ?>/images/email.png"/></a></div>
	<?php } if ($trans_email_disable) { 
			// Email Icon Disabled
	 	  } ?>
	
	<!-- Twitter Icon-->
	<?php if( (!$trans_twitter_username) && (!$trans_twitter_disable) ) { ?>
			<div class="header_socials"><a href="http://twitter.com/"><img alt="twitter" src="<?php bloginfo( 'template_directory' ); ?>/images/twitter.png"/></a></div>
	<?php } if( ($trans_twitter_username) && (!$trans_twitter_disable) ) { ?>
			<div class="header_socials"><a href="http://twitter.com/<?php echo $trans_twitter_username; ?>"><img alt="twitter" src="<?php bloginfo( 'template_directory' ); ?>/images/twitter.png"/></a></div>
	<?php } if ($trans_twitter_disable) { 
			// Twitter Icon Disabled
	 	  } ?>
	
	<!-- Facebook Icon-->
	<?php if( (!$trans_facebook_username) && (!$trans_facebook_disable) ) { ?>
			<div class="header_socials"><a href="http://www.facebook.com/"><img alt="facebook" src="<?php bloginfo( 'template_directory' ); ?>/images/facebook.png"/></a></div>
	<?php } if( ($trans_facebook_username) && (!$trans_facebook_disable) ) { ?>
			<div class="header_socials"><a href="http://www.facebook.com/<?php echo $trans_facebook_username; ?>"><img alt="facebook" src="<?php bloginfo( 'template_directory' ); ?>/images/facebook.png"/></a></div>
	<?php } if ($trans_facebook_disable) { 
			// Facebook Icon Disabled
	 	  } ?>
</div><!-- social_media -->


<div id="main_navigation" class="jqueryslidemenu"><ul>
	<?php wp_list_pages('sort_column=menu_order&title_li='); ?></ul>
</div><!-- main_navigation -->		
		
	<div id="header_searchbar"><?php include (TEMPLATEPATH . '/searchform.php'); ?></div>						
			<div id="header_image" ></div>																			
			<div id="header_overlay"></div>

			<br class="clearboth" />
			
		</div><!-- inner_header -->
	</div><!-- header -->
	
<div id="inner_body_block_head"></div>
<div id="body_block">
	<div id="primary">
		<div class="content">
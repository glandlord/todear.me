<h3 id="blog_pages">Pages</h3>
	<ul><?php wp_list_pages('exclude=12&title_li=' ); ?></ul>
	<p style="display:block;text-align:right;font-size:0.8em;clear:both;padding-bottom:30px;">|
		<a style="padding:1px;" href="#blog_feeds">Skip <?=$blog_categories ?></a> | 
		<a style="padding:1px;" accesskey="t" href="#">Top</a> | </p>
<hr />

<h3 id="blog_feeds">Feeds</h3>
	<ul>
		<li><a title="Full content" href="feed:<?php bloginfo('rss2_url'); ?>">Main RSS</a></li>
		<li><a title="Comment Feed" href="feed:<?php bloginfo('comments_rss2_url'); ?>">Comment Feed</a></li>
	</ul>	
	<p style="display:block;text-align:right;font-size:0.8em;clear:both;padding-bottom:30px;">|
		<a style="padding:1px;" href="#blog_archives">Skip <?=$blog_categories ?></a> | 
		<a style="padding:1px;" accesskey="t" href="#">Top</a> | </p>
<hr />
	
	
<h3 id="blog_categories">Categories</h3>
	<ul><?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0&feed=RSS'); ?></ul>
	<p style="display:block; text-align:right;font-size:0.8em;clear:both;padding-bottom:30px;">|
		<a style="padding:1px;" href="#the_links">Skip <?=$blog_archives ?></a> | 
		<a style="padding:1px;" accesskey="t" href="#">Top</a> | </p>
<hr />

<h3>All internal blog posts:</h3>
	<a href="javascript:expandIt(document.getElementById('link0055'))">[+/-]  Get all posts</a> 
	<div id="link0055" style="display: none;">
		<ul><?php $archive_query = new WP_Query('showposts=1000');
			while ($archive_query->have_posts()) : $archive_query->the_post(); ?>
				<li>
					<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a> 
					<strong><?php comments_number('0', '1', '%'); ?></strong>
				</li>
			<?php endwhile; ?>
		</ul>
	</div>
	<p style="display:block; text-align:right;font-size:0.8em;clear:both;"> |
		<a style="padding:1px;" href="#the_links">Skip <?=$blog_archives ?> </a> | 
		<a style="padding:1px;" accesskey="t" href="#">Top</a>|</p>
<hr />


<h3 id="blog_archives">Archives</h3>
	<ul>
		<?php wp_get_archives('type=monthly&show_post_count=true'); ?>
	</ul>
	<p style="display:block; text-align:right;font-size:0.8em;clear:both;"> |
		<a style="padding:1px;" accesskey="t" href="#">Top</a>| </p>
<hr />
<?php get_header(); ?>

<?php if(have_posts()) : ?>

<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
<?php /* If this is a category archive */ if (is_category()) { ?>
<h1 class="page_title">Archive for the &lsquo;<?php single_cat_title(); ?>&rsquo; Category</h1>
<?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
<h1 class="page_title">Posts Tagged &lsquo;<?php single_tag_title(); ?>&rsquo;</h1>
<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
<h1 class="page_title">Archive for <?php the_time('F jS, Y'); ?></h1>
<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
<h1 class="page_title">Archive for <?php the_time('F, Y'); ?></h1>
<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
<h1 class="page_title">Archive for <?php the_time('Y'); ?></h1>
<?php /* If this is an author archive */ } elseif (is_author()) { ?>
<h1 class="page_title">Author Archive</h1>
<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
<h1 class="page_title">Blog Archives</h1>
<?php } ?>
	
<?php while(have_posts()) : the_post(); ?>

	<div class="post" id="post_id_<?php the_ID(); ?>">		
		<h2 class="blog_h2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>		
		<div class="top_metadata">
			<div class="comment_count">
				<?php comments_popup_link('no comments', '1 comment', '% comments'); ?>
			</div>
			<div class="date_author">
				Posted on <?php the_time('M') ?> <?php the_time('j') ?> <?php the_time('Y') ?> by <?php the_author_posts_link(); ?> 
			</div>	
		</div>			
		<div class="entry">
			<?php the_excerpt(); ?>
		</div>						
		<br class="clearboth" />
			<div class="more_link"><a href="<?php the_permalink(); ?>">Read More</a></div>			
		<br class="clearboth" />
		<div class="bottom_metadata">
			<span class="tags">
			<?php the_tags('&nbsp;&nbsp;<strong>Tags</strong>: <em>', '</em>, <em>', '</em>'); ?>
			</span>		
			<?php if ( count(($categories=get_the_category())) > 1 || $categories[0]->cat_ID != 1 ) : ?>
			 <strong>Category:</strong> 
			 <?php the_category(', ') ?>
			<?php endif; ?>
			<?php edit_post_link('Edit', '&nbsp;&nbsp;(&nbsp;&nbsp;', '&nbsp;&nbsp;)&nbsp;&nbsp;'); ?>
		</div>				
	</div> <!-- post -->

<?php endwhile; endif; ?>

	<div class="blog_navigation">
		<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
		<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
	</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
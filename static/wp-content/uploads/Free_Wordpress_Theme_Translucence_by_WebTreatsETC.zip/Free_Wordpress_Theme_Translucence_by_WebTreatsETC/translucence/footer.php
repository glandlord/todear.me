<br class="clearboth" />		
</div><!-- body_block -->
<div id="inner_body_block_foot"></div><!-- inner_body_block_foot -->

<div id="footer">
	<div id="inner_footer">

			<div id="footer_nav"><ul>
				<?php wp_list_pages('depth=1&sort_column=menu_order&title_li='); ?>
			</ul></div>						
			<div id="footer_link"><a href="http://wordpress.org">Powered by Wordpress</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://webtreats.mysitemyway.com">Designed by WebTreats</a></div>											
			
		<br class="clearboth" />				
	</div><!-- inner_footer -->
</div><!-- footer -->
</div><!-- Container -->
</div><!-- bg_footer -->
</div><!-- bg_header -->
</div><!-- bg_middle -->

<?php require(TEMPLATEPATH . "/var.php"); ?>
<?php wp_footer(); ?>
<?php if ( $trans_analytics_code <> "" ) { echo stripslashes($trans_analytics_code); } ?>
<script type="text/javascript">
/* <![CDATA[ */
function expandIt(getIt){getIt.style.display=(getIt.style.display=="none")?"":"none";}
/* ]]> */
</script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ); ?>/inc/slide.js"></script>
</body>
</html>
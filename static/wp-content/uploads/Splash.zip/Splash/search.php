<?php get_header(); ?>
 
                   <div id="cont-col">
                        <div class="ind">
                        	<div class="corner-top-left png">
                            	<div class="corner-top-right png">
                                	<div class="border-top png"><div></div></div>
                                </div>
                            </div>
							<div class="border-right png">
                            	<div class="bg-cont png">
                                	<div class="inner">
                                    											                                                                                                                                         
                                                                            
                                                                            
                                          <!-- start main content -->
<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>
		
                                        <div class="node">
											<h1 class="title"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
											<div class="submit"><span class="submitted">Submitted by <?php the_author() ?> on <?php the_time('F jS, Y') ?></span>
											</div>
											<div class="taxonomy">
											</div>
  
											<div class="content">
												<?php the_excerpt(); ?>
												<div class="clear"></div>
											</div>

												<p class="postmetadata"><?php the_tags('Tags: ', ', ', '<br />'); ?> Posted in <?php the_category(', ') ?> | <?php edit_post_link('Edit', '', ' | '); ?>  <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></p>
				
											<div class="clear"></div>
										</div>
	
<?php endwhile; ?>

										<div class="navigation">
											<?php
												if(!function_exists('wp_pagenavi')) { 
													include('wp-pagenavi.php');
												}
												wp_pagenavi(); 
											?>
										</div>

<?php else : ?>

										<h2 class="center">Not Found</h2>
										<p class="center">Sorry, but you are looking for something that isn't here.</p>
										<?php get_search_form(); ?>

<?php endif; ?>
	
									</div>
                                </div>
                            </div>
							
                            <div class="corner-bot-left png">
                            	<div class="corner-bot-right png">
                                	<div class="border-bot png"><div></div>
									</div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
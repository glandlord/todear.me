                </div>
            </div>
                    
        </div>
        <div id="footer">
            <div class="foot">
                                    <span>Copyright &copy; <?php echo date('Y'); ?> - <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>. All Rights Reserved | Splash Theme by <a href="http://dynamicwp.net">Dynamicwp team</a> | Powered by <a href="http://wordpress.org">wordpress</a><!--{%FOOTER_LINK} --></span>
                            </div>
        </div>
    </div>
 
<?php wp_footer();?>
</body>
</html>
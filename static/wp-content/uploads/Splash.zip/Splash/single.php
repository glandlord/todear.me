<?php get_header(); ?>
 
                   <div id="cont-col">
                        <div class="ind">
                        	<div class="corner-top-left png">
                            	<div class="corner-top-right png">
                                	<div class="border-top png"><div></div></div>
                                </div>
                            </div>
							<div class="border-right png">
                            	<div class="bg-cont png">
                                	<div class="inner">
                                    											                                                                                                                                         
                                                                            
                                                                            
                                          <!-- start main content -->
<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>
		
                                        <div class="node">
											<h1 class="title"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
											<div class="submit"><span class="submitted">Submitted by <?php the_author() ?> on <?php the_time('F jS, Y') ?></span>
											</div>
											<div class="taxonomy">
											</div>
  
											<div class="content">
												<?php the_content('Read the rest of this entry &raquo;'); ?>
												<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
												<div class="clear"></div>
											</div>
<p class="postmetadata"><?php the_tags('Tags: ', ', ', '<br />'); ?> Posted in <?php the_category(', ') ?> | <?php edit_post_link('Edit', '', ' | '); ?>  <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></p>
												<?php  edit_post_link('Edit this entry','','.'); ?>
<br />
											<h2 style="margin-bottom: 3px;">Share This Post</h2>
											<div class="addthis_toolbox">
																		<a class="addthis_button_twitter"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/twitter.png" width="32" height="32" alt="Twitter" /></a>
																		<a class="addthis_button_delicious"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/delicious.png" width="32" height="32" alt="Delicious" /></a>
																		<a class="addthis_button_facebook"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/facebook.png" width="32" height="32" alt="Facebook" /></a>
																		<a class="addthis_button_digg"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/digg.png" width="32" height="32" alt="Digg" /></a>
																		<a class="addthis_button_stumbleupon"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/stumbleupon.png" width="32" height="32" alt="Stumbleupon" /></a>
																		<a class="addthis_button_favorites"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/favorites.png" width="32" height="32" alt="Favorites" /></a>
																		<a class="addthis_button_more"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/more.png" width="32" height="32" alt="More" /></a>
																<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js?pub=xa-4a65e1d93cd75e94"></script>
											</div>
												
												<?php comments_template('', true); ?>
											<div class="clear"></div>
										</div>
	
<?php endwhile; ?>



<?php else : ?>

										<h2 class="center">Not Found</h2>
										<p class="center">Sorry, but you are looking for something that isn't here.</p>
										<?php get_search_form(); ?>

<?php endif; ?>
	
									</div>
                                </div>
                            </div>
							
                            <div class="corner-bot-left png">
                            	<div class="corner-bot-right png">
                                	<div class="border-bot png"><div></div>
									</div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
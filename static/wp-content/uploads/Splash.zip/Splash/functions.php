<?php 
if ( function_exists('register_sidebar') ) {
	register_sidebar(array(
		'before_widget' => '<div class="widget">
												<div id="left-col">
													<div class="ind">
														<div class="side_right_a">
															<div class="side_right_c">
																<div class="side_right_b"><div></div></div>
															</div>
														</div>
														<div id="side_right">
														<div class="width">
															<div class="block block-user">',
		'after_widget' => '									</div>                                					
														</div></div>
														<div class="side_right_f">
															<div class="side_right_h">
																<div class="side_right_g"><div></div>
																</div>
															</div>
														</div>
													</div>
												</div>
							</div>',
		'before_title' => '<h2 class="widgettitle">',
		'after_title' => '</h2>',
	));
}

?>
<?php //function for theme option

add_action('admin_menu', 'magazine_add_theme_page');
// function to select a category
function ml_input( $var, $type, $description = "", $value = "", $selected="" ) {

	// ------------------------
	// add a form input control
	// ------------------------
	
 	echo "\n";
 	
	switch( $type ){
	
	    case "text":

	 		echo "<input name=\"$var\" id=\"$var\" type=\"$type\" style=\"width: 60%\" class=\"textbox\" value=\"$value\" />";
			
			break;
			
		case "submit":
		
	 		echo "<p class=\"submit\"><input name=\"$var\" type=\"$type\" value=\"$value\" /></p>";

			break;

		case "option":
		
			if( $selected == $value ) { $extra = "selected=\"true\""; }

			echo "<option value=\"$value\" $extra >$description</option>";
		
		    break;

	}

}

function magazine_add_theme_page() {
	if ( $_GET['page'] == basename(__FILE__) ) {
	
	    // save settings
		if ( 'save' == $_REQUEST['action'] ) {

			update_option( 'sidebar_post_cat_id', $_POST['sidebar_cat_id'] );
			update_option( 'sidebar_post_cat_id2', $_POST['sidebar_cat_id2'] );
			update_option( 'sidebar_post_cat_id3', $_POST['sidebar_cat_id3'] );
			update_option( 'timthumb', $_POST['timthumb'] );
			update_option( 'logo', $_POST['logo'] );			
			update_option( 'gambar1', $_POST['image1'] );
			update_option( 'gambar2', $_POST['image2'] );
			update_option( 'gambar3', $_POST['image3'] );


			header("Location: themes.php?page=functions.php&saved=true");
			die;

  		// reset settings
		} else if( 'reset' == $_REQUEST['action'] ) {

			delete_option( 'sidebar_post_cat_id' );			
			delete_option( 'sidebar_post_cat_id2' );			
			delete_option( 'sidebar_post_cat_id3' );
			update_option( 'timthumb', $_POST['timthumb'] );			
			delete_option( 'logo' );			
			delete_option( 'gambar1' );			
			delete_option( 'gambar2' );			
			delete_option( 'gambar3' );	
	
			// goto theme edit page
			header("Location: themes.php?page=functions.php&reset=true");
			die;

		}
	}


    add_theme_page("<span style=\"color:#FF0000; font-wight: bold;\" > Splash Options</span>", "<span style=\"color:#FF0000; font-weight: bold;\"> Splash Options</span>", 'edit_themes', basename(__FILE__), 'magazine_theme_page');

} 

function magazine_theme_page() {

	// --------------------------
	// VideoDen theme page content
	// --------------------------

	if ( $_REQUEST['saved'] ) echo '<div id="message" class="updated fade"><p><strong>Magazine Theme: Settings saved.</strong></p></div>';
	if ( $_REQUEST['reset'] ) echo '<div id="message" class="updated fade"><p><strong>Magazine Theme: Settings reset.</strong></p></div>';
	
?>

    <div class="wrap">
        <h2>Homepage Options:</h2>
        <form method="post" action="">
<?php

if ($_POST['sidebar_cat_id']) {
        update_option('sidebar_post_cat_id', $_POST['sidebar_cat_id']);
    }
    $cats = get_categories();
if ($_POST['sidebar_cat_id2']) {
        update_option('sidebar_post_cat_id2', $_POST['sidebar_cat_id2']);
    }
    $cats2 = get_categories();
if ($_POST['sidebar_cat_id3']) {
        update_option('sidebar_post_cat_id3', $_POST['sidebar_cat_id3']);
    }
    $cats3 = get_categories();
	
if ($_POST['timthumb']) {
        update_option('timthumb', $_POST['timthumb']);
    }
	
if ($_POST['logo']) {
        update_option('logo', $_POST['logo']);
    }
	
if ($_POST['image1']) {
        update_option('gambar1', $_POST['image1']);
    }
if ($_POST['image2']) {
        update_option('gambar2', $_POST['image2']);
    }
if ($_POST['image3']) {
        update_option('gambar3', $_POST['image3']);
    }


?>

		<b>Link To your Logo Image: </b><br />
		Logo Image &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type="textarea" name="logo" size="120" <?php if (get_option('logo')){ ?>value="<?php echo get_option('logo'); ?>" <?php } ?>/><br />
		<small>Use full url format(with http://). If you let the column empty, default logo is used</small>
		<br /><br /><br />	
		<b>Slide Show Images Setting : </b> <br />
		first image &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type="textarea" name="image1" size="120" <?php if (get_option('gambar1')){ ?>value="<?php echo get_option('gambar1'); ?>" <?php } ?>/><br />

		second image &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type="textarea" name="image2" size="120"<?php if (get_option('gambar2')){ ?>value="<?php echo get_option('gambar2'); ?>" <?php } ?>/><br />

		third image &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type="textarea" name="image3" size="120"<?php if (get_option('gambar3')){ ?>value="<?php echo get_option('gambar3'); ?>" <?php } ?>/><br />
		<small>Use full url format(with http://). If you let the columns empty, default images are used</small>
		<br /><br /><br />
		
		<b>Featured Posts Settings :</b><br />
        First featured post category: <select name="sidebar_cat_id">
            <?php
            foreach ($cats as $cat) {
            $option = '<option value="'.$cat->cat_ID.'"';
            if ($cat->cat_ID == get_option('sidebar_post_cat_id')) { $option .= ' SELECTED >'; } else { $option .= ">"; }
            $option .= $cat->cat_name;
            $option .= '</option>';
            echo $option; }
            ?>
        </select><br/><br/>
		
        Second featured post category: <select name="sidebar_cat_id2">
            <?php
            foreach ($cats2 as $cat) {
            $option2 = '<option value="'.$cat->cat_ID.'"';
            if ($cat->cat_ID == get_option('sidebar_post_cat_id2')) { $option2 .= ' SELECTED >'; } else { $option2 .= ">"; }
            $option2 .= $cat->cat_name;
            $option2 .= '</option>';
            echo $option2; }
            ?>
        </select><br/><br/>
		
        Third featured post category: <select name="sidebar_cat_id3">
            <?php
            foreach ($cats3 as $cat) {
            $option3 = '<option value="'.$cat->cat_ID.'"';
            if ($cat->cat_ID == get_option('sidebar_post_cat_id3')) { $option3 .= ' SELECTED >'; } else { $option3 .= ">"; }
            $option3 .= $cat->cat_name;
            $option3 .= '</option>';
            echo $option3; }
            ?>
        </select><br/><br/><br />
		
		<b>If you have problem displaying thumbnail image, try changing this option: </b><br />
			Do not use timthumb : <input type="checkbox" name="timthumb" value="timthump" <?php if (get_option('timthumb')){ ?> checked="checked" <?php } ?> ><br /><br />


<input type="hidden" name="action" value="save" />
	<?php ml_input( "save", "submit", "", "Save Settings" );?>     </form><br/><br/>
<form method="post">

<h2>Reset</h2>

<p>If for whatever reason you want to "clean up" the settings set here or want to use another theme, click the <em>Reset Settings</em> button below.</p>
<?php

	ml_input( "reset", "submit", "", "Reset Settings" );
	
?>

<input type="hidden" name="action" value="reset" />
</form>

<h2>Support</h2>

<p>If you have any question about this theme, feel free to put your question  <a href="http://www.dynamicwp.net">here</a></p>

</div>

<?php } ?>
<?php
// function to set trackbacks
function list_pings($comment, $args, $depth) {
       $GLOBALS['comment'] = $comment;
?>
<li id="comment-<?php comment_ID(); ?>"><?php comment_author_link(); ?>
<?php } ?>
<?php
function catch_that_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  $first_img = $matches [1] [0];

  return $first_img;
}
?>
<?php
/*
Plugin Name: Excerpt Link Modifier
Plugin URI: http://aweconsulting.co.uk
Description: This plugin replaces [...]
Version: 1
Author: Ned Storm
Author URI: http://aweconsulting.co.uk
*/

function excerpt_link_modifier_install() {
    global $wpdb;
}

function excerpt_link_modify() {
    if ( '' == $text ) {
        $text = get_the_content('');

        $text = strip_shortcodes( $text );

        $text = apply_filters('the_content', $text);
        $text = str_replace(']]>', ']]>', $text);
        $text = strip_tags($text);
        $excerpt_length = apply_filters('excerpt_length', 100);
        $words = explode(' ', $text, $excerpt_length + 1);
        if (count($words) > $excerpt_length) {
            array_pop($words);
            array_push($words, '...');
            $text = implode(' ', $words);
        }
    }
    return $text;
}

register_activation_hook(__FILE__, 'excerpt_link_modifier_install');

add_filter('get_the_excerpt','excerpt_link_modify'); 

function excerpt_link_modify2() {
    if ( '' == $text ) {
        $text = get_the_content('');

        $text = strip_shortcodes( $text );

        $text = apply_filters('the_content', $text);
        $text = str_replace(']]>', ']]>', $text);
        $text = strip_tags($text);
        $excerpt_length = apply_filters('excerpt_length', 25);
        $words = explode(' ', $text, $excerpt_length + 1);
        if (count($words) > $excerpt_length) {
            array_pop($words);
            array_push($words, '...');
            $text = implode(' ', $words);
        }
    }
    echo $text;
}
?>
<?php include( TEMPLATEPATH . '/header.php' ); ?>

                   <div id="cont-col">
                        <div class="ind">
                        	<div class="corner-top-left png">
                            	<div class="corner-top-right png">
                                	<div class="border-top png"><div></div></div>
                                </div>
                            </div>
							<div class="border-right png">
                            	<div class="bg-cont png">
                                	<div class="inner">
                                    											                                                                                                                                         
                                                                            
                                                                            
                                          <!-- start main content -->
<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>
	<?php if ($post->ID != $featured_ID && $post->ID != $featured2_ID && $post->ID != $featured3_ID): ?>
                                        <div class="node">
											<h1 class="title"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
											<div class="submit"><span class="submitted">Submitted by <?php the_author() ?> on <?php the_time('F jS, Y') ?></span>
											</div>  
											<div class="content">
											<?php if (catch_that_image()){?>
											<?php if (!get_option('timthumb')) { ?><img class="bordered main-image" src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo catch_that_image(); ?>&w=125&h=125&zc=1"><?php } else { ?><img class="bordered main-image" src="<?php echo catch_that_image(); ?>" style="width:125px; height:125px" /><?php }?>							
											<?php }?>
													<?php
													  $myExcerpt = get_the_excerpt();
													  $tags = array("<p>", "</p>");
													  $myExcerpt = str_replace($tags, "", $myExcerpt);
													  echo $myExcerpt;
													?> 
												<div class="clear"></div>
											</div>

												<p class="postmetadata"><?php the_tags('Tags: ', ', ', '<br />'); ?> Posted in <?php the_category(', ') ?> | <?php edit_post_link('Edit', '', ' | '); ?>  <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></p>
				
											<div class="clear"></div>
										</div>
	<?php endif; ?>
<?php endwhile; ?>

										<div class="navigation">
											<?php
												if(!function_exists('wp_pagenavi')) { 
													include('wp-pagenavi.php');
												}
												wp_pagenavi(); 
											?>
										</div>

<?php else : ?>

										<h2 class="center">Not Found</h2>
										<p class="center">Sorry, but you are looking for something that isn't here.</p>
										<?php get_search_form(); ?>

<?php endif; ?>
	
									</div>
                                </div>
                            </div>
							
                            <div class="corner-bot-left png">
                            	<div class="corner-bot-right png">
                                	<div class="border-bot png"><div></div>
									</div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
                                            <div id="right-col">
											<?php if (is_home()){?>
											<div class="addthis_toolbox">
																		<a class="addthis_button_twitter"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/twitter.png" width="32" height="32" alt="Twitter" /></a>
																		<a class="addthis_button_delicious"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/delicious.png" width="32" height="32" alt="Delicious" /></a>
																		<a class="addthis_button_facebook"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/facebook.png" width="32" height="32" alt="Facebook" /></a>
																		<a class="addthis_button_digg"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/digg.png" width="32" height="32" alt="Digg" /></a>
																		<a class="addthis_button_stumbleupon"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/stumbleupon.png" width="32" height="32" alt="Stumbleupon" /></a>
																		<a class="addthis_button_favorites"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/favorites.png" width="32" height="32" alt="Favorites" /></a>
																		<a class="addthis_button_more"><img src="<?php bloginfo('template_directory'); ?>/images/socialicons/more.png" width="32" height="32" alt="More" /></a>
																<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js?pub=xa-4a65e1d93cd75e94"></script>
											</div>
											<?php }?>
												<?php 	/* Widgetized sidebar, if you have the plugin installed. */
													if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
						                        <div id="left-col">
													<div class="ind">
														<div class="side_right_a">
															<div class="side_right_c">
																<div class="side_right_b"><div></div></div>
															</div>
														</div>
														<div id="side_right">
														<div class="width">
															<div class="block block-user">
																<div class="title">
																	<h3>Archives</h3>
																</div>
																<div class="content"><ul class="menu">
																	<?php wp_get_archives('type=monthly'); ?></ul>
																</div>
															</div>                                					
														</div></div>
														<div class="side_right_f">
															<div class="side_right_h">
																<div class="side_right_g"><div></div>
																</div>
															</div>
														</div>
													</div>
												</div>											
												<div class="ind">
													<div class="side_right_a">
														<div class="side_right_c">
															<div class="side_right_b"><div></div></div>
														</div>
													</div><div id="side_right">
													<div class="width">
														<div class="block block-user">

															<div class="title">
																<h3>list Category</h3>
															</div>
															<div class="content">
																<ul class="menu"><?php wp_list_categories('show_count=1&title_li=<h2>Categories</h2>'); ?></ul>
															</div>
														</div>                             					
													</div></div>
													<div class="side_right_f">
														<div class="side_right_h">
															<div class="side_right_g"><div></div>
															</div>
														</div>
													</div>
												</div>
												<?php endif; ?>
											</div>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>


<link rel="shortcut icon" href="<?php bloginfo('stylesheet_directory'); ?>/images/favicon.ico" type="image/x-icon" />

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
    

<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/superfis.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/scrollTo.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/serialSc.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/init0000.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/custom00.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/function.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jqueryslidemenu.js"></script>

	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
</head>
  
<body id="body">
	<div class="min-width png">
        <div id="main">
            <div id="header">
                <div class="head-row1">
                	<div class="col1">
                    	<a href="<?php echo get_option('home'); ?>" title="Home"><img src="<?php if (get_option('logo')) : echo get_option('logo'); else: bloginfo('stylesheet_directory');?>/images/logo.png<?php endif; ?>" alt="Home" class="logo" /></a>
                    </div>
                    
                </div>
                <div class="head-row2 png">
                	<div class="col1">
                    	<div id="wrapper-top-menu" class="wrapper-top-menu">
                            <ul class="links menu-nav"><li class="cat-item"><a href="<?php echo get_option('home'); ?>" title="Home">home</a></li><?php wp_list_categories('title_li=&' ); ?></ul> 
						</div>
		<script type="text/javascript">
			jqueryslidemenu.buildmenu("wrapper-top-menu", arrowimages);
		</script>						
                    </div>
                    <div class="col2">
                    	<div class="search-box"><?php include(TEMPLATEPATH . '/searchform.php' ); ?>
                        </div>
                    </div>
                </div>
				<?php if (is_home() && !is_paged()) : ?>
               	<div style="clear: both;"></div>
<div class="featured">
    <div id="sections">
        <ul> 
			<li style="">
				<img src="<?php if (get_option('gambar1')){ echo get_option('gambar1');} else { bloginfo('stylesheet_directory');?>/images/thumb.jpg<?php } ?>" />
            </li>
			<li style="">
				<img src="<?php if (get_option('gambar2')){ echo get_option('gambar2');} else { bloginfo('stylesheet_directory');?>/images/thumb.jpg<?php } ?>" />
            </li>
			<li style="">
				<img src="<?php if (get_option('gambar3')){ echo get_option('gambar3');} else { bloginfo('stylesheet_directory');?>/images/thumb.jpg<?php } ?>"  />
            </li>
	    </ul>
    </div> <!-- -end sections -->
    <div id="featured-right">
        <div id="sections2">
            <ul>
				<?php
					$topfeatured = new WP_Query();
					$topfeatured->query('showposts=3');
					if($topfeatured->have_posts()) : while($topfeatured->have_posts()): $topfeatured->the_post();
				?>
					<li>
						<h2 class="featured-title"><a href="<?php the_permalink(); ?>" title="Permanent Link to <?php the_title();?>"><?php the_title();?></a></h2>
						<div class="featured-info"><?php the_time('F jS, Y'); ?> by <?php the_author(); ?> </div>
						<?php excerpt_link_modify2() ?>
						<div style="clear: both;"></div>
						<a href="<?php the_permalink(); ?>" class="featured-readmore">read more</a> 
					</li>
				<?php endwhile; ?>
				<?php endif; ?>
				
               </ul>
        </div> <!-- -end sections2 -->
        <div style="clear: both;"></div>
        <div id="featured-button">
            <div class="prev">
                <div class="prev-hover"> </div>
            </div>
            <div class="next">
                <div class="next-hover"></div>
            </div>
        </div> <!-- -end featured-bottom -->
    </div> <!-- -end featured-right -->
</div> 
                <div class="head-row4" id="custom">
                    <div class="ind">
						<div class="block block-block" id="block-block-14">
							<div class="content">
								<div id="icon">
									<?php
										$featured = new WP_Query();
										$featured->query('showposts=1&cat='.get_option('sidebar_post_cat_id'));
										if($featured->have_posts()) : while($featured->have_posts()): $featured->the_post();
										$featured_ID = $post->ID;
									?>
										<div class="title">
											<h3><a href="<?php the_permalink(); ?>" title="<?php the_title();?>"><?php the_title();?></a></h3>
										</div>
										<div class="block-content">
											<?php if (catch_that_image()):?>
											<?php if (!get_option('timthumb')) { ?><img class="bordered" src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo catch_that_image(); ?>&w=269&h=126&zc=1"><?php } else { ?><img class="bordered" src="<?php echo catch_that_image(); ?>" style="width:269px; height:126px" /><?php }?>									
											<?php else:?>
											<img class="bordered" src="<?php bloginfo('template_directory'); ?>/images/image.jpg" />
											<?php endif; ?>	
											<?php excerpt_link_modify2(); ?>
										</div>

									<?php endwhile; ?>
									<?php endif; ?>									
									<div class="category-menu">
														
										<div class="category clearfix">
											<div><a href=""><span class="indicator"></span> More On <?php if (!get_option('sidebar_post_cat_id')) : echo 'Category'; else: echo get_cat_name(get_option('sidebar_post_cat_id')); endif; ?></a></div>
										</div>
										<div class="clear"></div>						
										<div class="dropdown">
											<ul class="cat-posts">
												<?php
													$featured = new WP_Query();
													$featured->query('showposts=4&cat='.get_option('sidebar_post_cat_id'));
													if($featured->have_posts()) : while($featured->have_posts()): $featured->the_post();
													if ($post->ID != $featured_ID):
												?>
													
														<li><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title();?>"><?php the_title();?></a><span> <?php the_time('F jS, Y'); ?></span></li>
																									
													
												<?php endif; ?>
												<?php endwhile; ?>
												<?php endif; ?>
												<li class="view-more"><a href="<?php echo get_category_link( get_option('sidebar_post_cat_id') ); ?>" class="view-more">View More &raquo;</a></li>	
												<div class="clear"></div>
											</ul>
											<div class="clear"></div>
										</div><!-- End dropdown -->
							
									</div><!-- End category -->
								</div>
							</div>
						</div>
						<div class="block block-block" id="block-block-15">
							<div class="content">
								<div id="icon">
									<?php
										$featured2 = new WP_Query();
										$featured2->query('showposts=1&cat='.get_option('sidebar_post_cat_id2'));
										if($featured2->have_posts()) : while($featured2->have_posts()): $featured2->the_post();
										$featured2_ID = $post->ID;
									?>
										<div class="title">
											<h3><a href="<?php the_permalink(); ?>" title="<?php the_title();?>"><?php the_title();?></a></h3>
										</div>
										<div class="block-content">
											<?php if (catch_that_image()):?>
											<?php if (!get_option('timthumb')) { ?><img class="bordered" src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo catch_that_image(); ?>&w=269&h=126&zc=1"><?php } else { ?><img class="bordered" src="<?php echo catch_that_image(); ?>" style="width:269px; height:126px" /><?php }?>									
											<?php else:?>
											<img class="bordered" src="<?php bloginfo('template_directory'); ?>/images/image.jpg" />
											<?php endif; ?>
											<?php excerpt_link_modify2(); ?>
										</div>

									<?php endwhile; ?>
									<?php endif; ?>		
									<div class="category-menu">
														
										<div class="category clearfix">
											<div><a href=""><span class="indicator"></span> More On <?php if (!get_option('sidebar_post_cat_id2')) : echo 'Category'; else: echo get_cat_name(get_option('sidebar_post_cat_id2')); endif; ?></a></div>
										</div>
																	
										<div class="dropdown">
											<ul class="cat-posts">
												<?php
													$featured2 = new WP_Query();
													$featured2->query('showposts=4&cat='.get_option('sidebar_post_cat_id2'));
													if($featured2->have_posts()) : while($featured2->have_posts()): $featured2->the_post();
													if ($post->ID != $featured2_ID):
												?>
													
														<li><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title();?>"><?php the_title();?></a><span> <?php the_time('F jS, Y'); ?></span></li>
													
												<?php endif; ?>
												<?php endwhile; ?>
												<?php endif; ?>
												<li class="view-more"><a href="<?php echo get_category_link( get_option('sidebar_post_cat_id2') ); ?>" class="view-more">View More &raquo;</a></li>
											</ul>
										</div><!-- End dropdown -->
							
									</div><!-- End category -->									
								</div>
							</div>
						</div>
						<div class="block block-block" id="block-block-16">
							<div class="content">
								<div id="icon">
									<?php
										$featured3 = new WP_Query();
										$featured3->query('showposts=1&cat='.get_option('sidebar_post_cat_id3'));
										if($featured3->have_posts()) : while($featured3->have_posts()): $featured3->the_post();
										$featured3_ID = $post->ID;
									?>
										<div class="title">
											<h3><a href="<?php the_permalink(); ?>" title="<?php the_title();?>"><?php the_title();?></a></h3>
										</div>
										<div class="block-content">
											<?php if (catch_that_image()):?>
											<?php if (!get_option('timthumb')) { ?><img class="bordered" src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo catch_that_image(); ?>&w=269&h=126&zc=1"><?php } else { ?><img class="bordered" src="<?php echo catch_that_image(); ?>" style="width:269px; height:126px" /><?php }?>									
											<?php else:?>
											<img class="bordered" src="<?php bloginfo('template_directory'); ?>/images/image.jpg" />
											<?php endif; ?>	
											<?php excerpt_link_modify2(); ?>
										</div>

									<?php endwhile; ?>
									<?php endif; ?>	
									<div class="category-menu">
														
										<div class="category clearfix">
											<div><a href=""><span class="indicator"></span> More On <?php if (!get_option('sidebar_post_cat_id3')) : echo 'Category'; else: echo get_cat_name(get_option('sidebar_post_cat_id3')); endif; ?></a></div>
										</div>
																	
										<div class="dropdown">
											<ul class="cat-posts">
												<?php
													$featured3 = new WP_Query();
													$featured3->query('showposts=4&cat='.get_option('sidebar_post_cat_id3'));
													if($featured3->have_posts()) : while($featured3->have_posts()): $featured3->the_post();
													if ($post->ID != $featured3_ID):
												?>
													
														<li><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title();?>"><?php the_title();?></a><span> <?php the_time('F jS, Y'); ?></span></li>
													
												<?php endif; ?>
												<?php endwhile; ?>
												<?php endif; ?>
												<li class="view-more"><a href="<?php echo get_category_link( get_option('sidebar_post_cat_id3') ); ?>" class="view-more">View More &raquo;</a></li>
											</ul>
										</div><!-- End dropdown -->
							
									</div><!-- End category -->									
								</div>
							</div>


						</div>              
					</div>
                </div>
				<?php endif; ?>
            </div>
            <div style="clear: both;"></div>
                            
            <div id="cont">
            	<div class="cont-inner">
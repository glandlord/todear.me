<?php get_header(); ?>
 
                   <div id="cont-col">
                        <div class="ind">
                        	<div class="corner-top-left png">
                            	<div class="corner-top-right png">
                                	<div class="border-top png"><div></div></div>
                                </div>
                            </div>
							<div class="border-right png">
                            	<div class="bg-cont png">
                                	<div class="inner">
                                    											                                                                                                                                         
                                                                            
                                                                            
                                          <!-- start main content -->
<?php if (have_posts()) : ?>
 	  <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
 	  <?php /* If this is a category archive */ if (is_category()) { ?>
      <h2>Archive for the &#8216;<?php single_cat_title(); ?>&#8217; Category</h2>
 	  <?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
		<h2>Posts Tagged &#8216;<?php single_tag_title(); ?>&#8217;</h2>
 	  <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
		<h2>Archive for <?php the_time('F jS, Y'); ?></h2>
 	  <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
		<h2>Archive for <?php the_time('F, Y'); ?></h2>
 	  <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
		<h2>Archive for <?php the_time('Y'); ?></h2>
	  <?php /* If this is an author archive */ } elseif (is_author()) { ?>
		<h2>Author Archive</h2>
 	  <?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
		<h2>Blog Archives</h2>
 	  <?php } ?>
<?php while (have_posts()) : the_post(); ?>
		
                                        <div class="node">
											<h1 class="title"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
											<div class="submit"><span class="submitted">Submitted by <?php the_author() ?> on <?php the_time('F jS, Y') ?></span>
											</div>
											<div class="taxonomy">
											</div>
  
											<div class="content">
												<?php the_excerpt(); ?>
												<div class="clear"></div>
											</div>

												<p class="postmetadata"><?php the_tags('Tags: ', ', ', '<br />'); ?><?php edit_post_link('Edit', '', ' | '); ?>  <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></p>
				
											<div class="clear"></div>
										</div>
	
<?php endwhile; ?>

										<div class="navigation">
											<?php
												if(!function_exists('wp_pagenavi')) { 
													include('wp-pagenavi.php');
												}
												wp_pagenavi(); 
											?>
										</div>
						<?php else :

							if ( is_category() ) { // If this is a category archive
								printf("<h2 class='center'>Sorry, but there aren't any posts in the %s category yet.</h2>", single_cat_title('',false));
							} else if ( is_date() ) { // If this is a date archive
								echo("<h2>Sorry, but there aren't any posts with this date.</h2>");
							} else if ( is_author() ) { // If this is a category archive
								$userdata = get_userdatabylogin(get_query_var('author_name'));
								printf("<h2 class='center'>Sorry, but there aren't any posts by %s yet.</h2>", $userdata->display_name);
							} else {
								echo("<h2 class='center'>No posts found.</h2>");
							}

						endif;
						?>
	
									</div>
                                </div>
                            </div>
							
                            <div class="corner-bot-left png">
                            	<div class="corner-bot-right png">
                                	<div class="border-bot png"><div></div>
									</div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
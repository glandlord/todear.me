
This folder is will store all the USER customizations, including changes in config, theme and user admin logins. The folder is initially empty in original release.

Imagevue V2 beta quickstart guide and other information: 
www.imagevuex.com/v2docs
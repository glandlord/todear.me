<?php

/*
 * userlist file, passwords is sha1 hash. for manually change passwords 
 * and generate hashes you can use http://www.md5.br-design.co.uk/ service
 */
 
 	$users['admin']['password'] = 'd033e22ae348aeb5660fc2140aec35850c4da997';
	$users['admin']['access'] = '*';
?>
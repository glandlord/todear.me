<?php

class ThemeController extends ivController
{
	/**
	 * Pre-dispatching
	 *
	 */
	function _preDispatch()
	{
		if (!ivAcl::isAdmin()) {
			$this->_forward('login', 'cred');
			if (ivAuth::getCurrentUserLogin()) {
				ivMessenger::add('error', "You don't have access to this page");
			}
			return;
		}
	}
	
	/**
	 * Default action
	 *
	 */
	function indexAction()
	{
		$crumbs = &ivPool::get('breadCrumbs');
		$crumbs->push('themes', 'index.php?c=theme');
		$selectedTheme = $this->conf->get('/config/imagevue/settings/theme');
		$themes = array_diff(ivTheme::getAllThemes(), array($selectedTheme));
		sort($themes);
		array_unshift($themes, $selectedTheme);
		$this->view->assign('theme', $selectedTheme);
		$this->view->assign('themes', $themes);
	}

	/**
	 * Edit theme cascade stylesheet
	 *
	 */
	function editcssAction()
	{
		$crumbs = &ivPool::get('breadCrumbs');
		$crumbs->push('themes', 'index.php?c=theme');
		$themeName = $this->_getParam('name', 'default', 'alnum');
		$crumbs->push($themeName . ' stylesheet', 'index.php?c=theme&amp;a=editcss&amp;name=' . $themeName);
		$theme = new ivTheme($themeName);
		$css = $this->_getParam('css');
		if (is_string($this->_getParam('save')) && is_string($css)) {
			if (@$theme->setStyle($css)) {
				ivMessenger::add('notice', 'CSS file succesfully saved');
			} else {
				ivMessenger::add('error', "Can't write to file $themeName/imagevue.css");
			}
		}
		$this->view->assign('theme', $theme);
		$this->view->assign('themes', ivTheme::getAllThemes());
	}

	/**
	 * Edit theme configuration
	 *
	 */
	function editconfigAction()
	{
		$crumbs = &ivPool::get('breadCrumbs');
		$crumbs->push('themes', 'index.php?c=theme');
		$themeName = $this->_getParam('name', 'default', 'alnum');
		$crumbs->push($themeName . ' config', 'index.php?c=theme&amp;a=editconfig&amp;name=' . $themeName);

		$theme = new ivTheme($themeName);
		if (!$theme->themeExists()) {
			$this->_redirect('index.php');
		}

		if (isset($_POST['save']) && isset($_POST['config'])) {
			$xml = $theme->getConfig();
			foreach ($_POST['config'] as $path => $value) {
				$node = &$xml->findByXPath($path);
				if ($node) {
					$node->setValue(is_array($value) ? implode(',', $value): (string) $value);
				}
			}
			$result = $xml->writeToFile();
			if ($result) {
				ivMessenger::add('notice', 'Theme configuration file succesfully saved');
			} else {
				ivMessenger::add('error', "Can't write to file");
			}
		}

		$xml = $theme->getConfig();

		$this->view->assign('flatConfig', $xml->toFlatTree());
		$this->view->assign('themes', ivTheme::getAllThemes());
		$this->view->assign('themeName', $themeName);

		if (isset($_COOKIE['ivconf'])) {
			$openedPanels = array_unique(array_explode_trim(',', $_COOKIE['ivconf']));
		} else {
			$openedPanels = array('config_settings3', 'config_controls35', 'config_audioplayer52', 'config_image64', 'config_thumbnails122', 'config_menu149', 'config_misc160', 'config_modules164', 'theme_style3', 'theme_controls23', 'theme_audioplayer36', 'theme_image40', 'theme_thumbnails89', 'theme_textpage121', 'theme_menu130', 'theme_modules159');
			setcookie('ivconf', implode(',', $openedPanels), time() + 365 * 86400);
		}
		$this->view->assign('openedPanels', $openedPanels);
	}

	/**
	 * Set default theme
	 *
	 */
	function useAction()
	{
		$value = $this->_getParam('name', 'default', 'alnum');
		if (!is_null($value)) {
			$xml = ivXml::readFromFile(CONFIG_FILE, DEFAULT_CONFIG_FILE);
			$node = &$xml->findByXPath('/config/imagevue/settings/theme');
			if ($node) {
				$node->setValue((string) $value);
			}
			$result = $xml->writeToFile();
			if ($result) {
				ivMessenger::add('notice', 'Configuration successfully saved');
			} else {
				ivMessenger::add('error', "Can't save configuration file " . substr(CONFIG_FILE, strlen(BASE_DIR)));
			}
		}
		$this->_redirect('index.php?c=theme');
	}
	
	/**
	 * Copy theme
	 *
	 */
	function copyAction()
	{
		$themeName = $this->_getParam('name', 'default', 'alnum');
		$newThemeName = $this->_getParam('new');
		if (!ctype_alnum($newThemeName)) {
			ivMessenger::add('error', 'Use only alphanumeric symbols in theme name');
			$this->_redirect('index.php?c=theme');
		}
		if (!$themeName || !$newThemeName) {
			$this->_redirect('index.php?c=theme&a=editconfig&name=' . $themeName);
		}
		if (!in_array($themeName, ivTheme::getAllThemes())) {
			ivMessenger::add('error', 'Theme named ' . $themeName . ' not found');
			$this->_redirect('index.php?c=theme');
		}
		if (in_array($newThemeName, ivTheme::getAllThemes())) {
			ivMessenger::add('error', 'Theme named ' . $newThemeName . ' already exists');
			$this->_redirect('index.php?c=theme&a=editconfig&name=' . $themeName);
		}
		$theme = new ivTheme($themeName);
		if ($theme->copyTo($newThemeName)) {
			ivMessenger::add('notice', "Theme $newThemeName succesfully created");
			$this->_redirect('index.php?c=theme&a=editconfig&name=' . $newThemeName);
		} else {
			ivMessenger::add('error', "Theme $newThemeName wasn't created");
			$this->_redirect('index.php?c=theme&a=editconfig&name=' . $themeName);
		}
	}

	/**
	 * Delete theme
	 *
	 */
	function deleteAction()
	{
		$themeName = $this->_getParam('name', null, 'alnum');
		$theme = new ivTheme($themeName);
		if (!$theme->themeExists()) {
			ivMessenger::add('error', 'Theme named ' . $themeName . ' not found');
			$this->_redirect('index.php?c=theme');
		}
		if ($theme->delete()) {
			ivMessenger::add('notice', "Theme $themeName succesfully deleted");
		} else {
			ivMessenger::add('error', "Theme $themeName wasn't deleted");
		}
		$this->_redirect('index.php?c=theme');
	}
	
	/**
	 * Upload background file
	 *
	 */
	function uploadAction()
	{
		$themeName = $this->_getParam('name', null, 'alnum');
		if (!$themeName) {
			$this->_redirect($_SERVER['HTTP_REFERER']);
		}
		$this->_setNoRender();
		if (!isset($_FILES['Filedata'])) {
			ivMessenger::add('error', 'File not found');
			$this->_redirect($_SERVER['HTTP_REFERER']);
		}
		$imageData = $_FILES['Filedata'];
		if (!@getimagesize($imageData['tmp_name'])) {
			ivMessenger::add('error', 'Incompatible file');
			$this->_redirect($_SERVER['HTTP_REFERER']);
		}
		$theme = new ivTheme($themeName);
		$fullpath = $theme->getUploadDirectory() . $imageData['name'];
		$result = @move_uploaded_file($imageData['tmp_name'], $fullpath);
		if ($result) {
			chmod($fullpath, 0777);
			ivMessenger::add('notice', "File {$imageData['name']} succesfully uploaded");
		} else {
			ivMessenger::add('notice', "File {$imageData['name']} wasn't uploaded");
		}
		$this->_redirect($_SERVER['HTTP_REFERER']);
	}

}
?>
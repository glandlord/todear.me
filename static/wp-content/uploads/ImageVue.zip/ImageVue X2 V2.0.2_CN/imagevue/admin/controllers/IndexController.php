<?php

class IndexController extends ivController
{
	/**
	 * Path
	 * @var string
	 */
	var $path;

	/**
	 * Content manager instance
	 * @var ivContentManager
	 */
	var $contentManager;

	/**
	 * Initialization
	 *
	 */
	function init()
	{
		$this->contentManager = &new ivContentManager();
	}
	
	/**
	 * Pre-dispatching
	 *
	 */
	function _preDispatch()
	{
		$path = $this->_getParam('path', ivFilepath::normalizeDir($this->conf->get('/config/imagevue/settings/contentfolder')), 'path');
		if (!ivAcl::isAllowedPath($path) && !ivAcl::isAllowedPath(ivFilePath::normalizeDir($path))) {
			if (is_null(ivAcl::getAllowedPath())) {
				$this->_forward('login', 'cred');
				return;
			} else {
				$path = ivAcl::getAllowedPath();
			}
		}
		$fullPath = ROOT_DIR . $path;
		if (is_dir($fullPath)) {
			$path = ivFilepath::normalizeDir($path);
		} elseif (is_file($fullPath)) {
			$this->_redirect('index.php?c=file&path=' . $path);
		} else {
			$this->_redirect('index.php');
		}
		$this->path = $path;
	}

	/**
	 * Default action
	 *
	 */
	function indexAction()
	{
		$folder = ivFSItem::create(ROOT_DIR . $this->path);

		// Save folder data
		$newdata = $this->_getParam('newdata');
		if (is_array($newdata)) {
			foreach ($newdata as $name => $value) {
				$folder->setAttribute($name, $value);
				$folder->setUserAttribute($name, $value);
			}
			if ($folder->save()) {
				ivMessenger::add('notice', 'Folder data succesfully saved');
			} else {
				ivMessenger::add('error', "Folder data wasn't saved");
			}
		}

		$contentFolder = ivFSItem::create(ROOT_DIR . ivAcl::getAllowedPath());
		$flatFolderTree = $contentFolder->getFlatFolderTree();

		$this->view->assign('path', $this->path);
		$this->placeholder->set('path', $this->path);
		$this->view->assign('flatFolderTree', $flatFolderTree);

		$this->view->assign('folder', $folder);
		$this->view->assign('sorts', ivFolder::getSortTypes());
		$this->view->assign('uploadLimit', min(realFileSize(ini_get('post_max_size')), realFileSize(ini_get('upload_max_filesize'))));
		$this->view->assign('allowedExtentions', $this->conf->get('/config/imagevue/settings/allowedext'));
		$this->view->assign('contentPath', ivFilepath::normalizeDir($this->conf->get('/config/imagevue/settings/contentfolder')));
		$this->view->assign('uploader', $this->conf->get('/config/imagevue/settings/uploader'));
		$this->view->assign('allowRenaming', ivFilepath::normalizeDir($this->path) !== ivFilepath::normalizeDir($this->conf->get('/config/imagevue/settings/contentfolder')));
	}
	
	/**
	 * Create new folder
	 *
	 */
	function createAction()
	{
		$newDirName = $this->_getParam('name');
		if (!preg_match('/^[_\w\d\s]+$/i', $newDirName)) {
			ivMessenger::add('error', 'Use only alphanumeric symbols and "_" symbol in folder name');
			$this->_redirect('index.php?path=' . $this->path);
		}
		if (is_string($newDirName)) {
			$newDirPath = ivFilepath::normalizeDir($this->path . $newDirName);
			if ($this->contentManager->create($newDirPath)) {
				ivMessenger::add('notice', 'Folder succesfully created');
			} else {
				ivMessenger::add('error', "Folder wasn't created");
			}
		}
		$this->_redirect('index.php?path=' . (isset($newDirPath) ? $newDirPath : $this->path));
	}
	
	/**
	 * Rename folder
	 *
	 */
	function renameAction()
	{
		if (ivFilepath::normalizeDir($this->path) === ivFilepath::normalizeDir($this->conf->get('/config/imagevue/settings/contentfolder'))) {
			ivMessenger::add('error', 'Cannot rename content folder');
			$this->_redirect('index.php?path=' . $this->path);
		}
		$newDirName = $this->_getParam('name');
		if (!preg_match('/^[_\w\d\s]+$/i', $newDirName)) {
			ivMessenger::add('error', 'Use only alphanumeric symbols and "_" symbol in folder name');
			$this->_redirect('index.php?path=' . $this->path);
		}
		$newDirPath = dirname($this->path) . '/' . $newDirName . '/';
		$result = @rename(ROOT_DIR . $this->path, ROOT_DIR . $newDirPath);
		if ($result) {
			ivMessenger::add('notice', 'Folder succesfully renamed');
			$this->_redirect('index.php?path=' . $newDirPath);
		} else {
			ivMessenger::add('error', 'Folder not renamed');
			$this->_redirect('index.php?path=' . $this->path);
		}
	}
	
	/**
	 * Delete folder
	 *
	 */
	function deleteAction()
	{
		if ($this->contentManager->remove($this->path)) {
			ivMessenger::add('notice', 'Folder succesfully deleted');
		} else {
			ivMessenger::add('error', 'Folder not deleted');
		}
		$this->_redirect('index.php');
	}

	/**
	 * Move files
	 *
	 */
	function moveFilesAction()
	{
		$targetDir = $this->_getParam('target', null, 'path');
		$moved = 0;
		$skipped = 0;
		foreach ($this->_getParam('selected', array()) as $file) {
			$result = $this->contentManager->move($this->path . $file, $targetDir);
			if ($result) {
				$moved++;
			} else {
				$skipped++;
			}
		}
		clearCache(ivFilepath::normalizeDir(ROOT_DIR . $this->path));
		ivMessenger::add('notice', $moved . ' files succesfully moved, ' . $skipped . ' files skipped');
		$this->_redirect('index.php?path=' . $this->path);
	}
	
	/**
	 * Copy files
	 *
	 */
	function copyFilesAction()
	{
		$targetDir = $this->_getParam('target', null, 'path');
		$copied = 0;
		$skipped = 0;
		foreach ($this->_getParam('selected', array()) as $file) {
			$result = $this->contentManager->copy($this->path . $file, $targetDir);
			if ($result) {
				$copied++;
			} else {
				$skipped++;
			}
		}
		ivMessenger::add('notice', $copied . ' files succesfully copied, ' . $skipped . ' files skipped');
		$this->_redirect('index.php?path=' . $this->path);
	}
	
	/**
	 * Delete files
	 *
	 */
	function deleteFilesAction()
	{
		$deleted = 0;
		$skipped = 0;
		foreach ($this->_getParam('selected', array()) as $file) {
			$result = $this->contentManager->remove($this->path . $file);
			if ($result) {
				$deleted++;
			} else {
				$skipped++;
			}
		}
		clearCache(ivFilepath::normalizeDir(ROOT_DIR . $this->path));
		ivMessenger::add('notice', $deleted . ' files succesfully deleted, ' . $skipped . ' files skipped');
		$this->_redirect('index.php?path=' . $this->path);
	}
	
	/**
	 * Hide folder
	 *
	 */
	function hideAction()
	{
		$folder = ivFSItem::create(ROOT_DIR . $this->path);
		$folder->setAttribute('hidden', 'true');
		$folder->save();
		$this->_redirect('index.php?path=' . $this->path);
	}
	
	/**
	 * Unhide folder
	 *
	 */
	function unhideAction()
	{
		$folder = ivFSItem::create(ROOT_DIR . $this->path);
		$folder->setAttribute('hidden', 'false');
		$folder->save();
		$this->_redirect('index.php?path=' . $this->path);
	}
	
	/**
	 * Upload file
	 *
	 */
	function uploadAction()
	{
		$this->_setNoRender();
		if (!isset($_FILES['Filedata'])) {
			header("HTTP/1.1 500 Internal Server Error");
			echo "Error. File not found";
			return;
		}
		$imageData = $_FILES['Filedata'];
		if (!ivFilepath::matchSuffix($imageData['name'], $this->conf->get('/config/imagevue/settings/allowedext'))) {
			header("HTTP/1.1 403 Forbidden");
			echo "Error. Wrong extention";
		} else {
			$fullpath = ROOT_DIR . $this->path . $imageData['name'];
			$result = @move_uploaded_file($imageData['tmp_name'], $fullpath);
			if ($result) {
				chmod($fullpath, 0777);
				$FSItem = ivFSItem::create($fullpath);
				$FSItem->generateThumb();
				clearCache(ROOT_DIR . $this->path);
				echo "File {$imageData['name']} succesfully uploaded";
			} else {
				header("HTTP/1.1 500 Internal Server Error");
				echo "Error. File {$imageData['name']} wasn't uploaded";
			}
		}
	}
	
	/**
	 * Recreate thumnails
	 *
	 */
	function makethumbsAction()
	{
		$_SESSION['remakeThumbs'] = true;
		$this->_redirect('index.php?path=' . $this->path);
	}

	/**
	 * Recreate thumnails recursive
	 *
	 */
	function recreatethumbsAction()
	{
		$folder = ivFSItem::create(ROOT_DIR . $this->path);
		$flatFolderTree = $folder->getFlatFolderTree();
		$this->view->assign('flatFolderTree', $flatFolderTree);
		$this->view->assign('missingOnly', $this->_getParam('miss', false, 'bool'));
		$this->view->assign('contentPath', ivFilepath::normalizeDir($this->conf->get('/config/imagevue/settings/contentfolder')));
	}

	/**
	 * Post-dispatching
	 *
	 */
	function _postDispatch()
	{
		$crumbs = &ivPool::get('breadCrumbs');
		$brCrumbsKeys = array_explode_trim('/', $this->path);
		if ($brCrumbsKeys !== false) {
			$lastCrumbKey = end($brCrumbsKeys);
			$path = '';
			foreach ($brCrumbsKeys as $key) {
				$path .= $key . '/';
				$folder = ivFSItem::create(ROOT_DIR . $path);
				if (!$folder) {
					continue;
				}
				if ($lastCrumbKey == $key) {
					$numOfFiles = $folder->getFileCount();
					$crumbs->push($folder->getTitle(), 'index.php?path=' . urlencode($path), '[' . $numOfFiles . ']', ($folder->isHidden() ? 'hidden' : ''));
				} else {
					$crumbs->push($folder->getTitle(), 'index.php?path=' . urlencode($path), '', ($folder->isHidden() ? 'hidden' : ''));
				}
			}
		}
	}

}
?>

<?php

class CredController extends ivController
{
	/**
	 * Log in
	 *
	 */
	function loginAction()
	{
		$this->_disableLayout();
		header("HTTP/1.1 403 Forbidden");
		$login = trim((string) $this->_getParam('login'));
		$password = trim((string) $this->_getParam('password'));
		if (!empty($login) && !empty($password)) {
			$rememberme = (boolean) $this->_getParam('rememberme');
			$result = ivAuth::authenticate($login, $password, $rememberme);
			if ($result) {
				ivMessenger::add('notice', "Welcome, $login");
			} else {
				ivMessenger::add('error', 'Incorrect login or password');
			}
			$this->_redirect($this->_getParam('redirect', $_SERVER['HTTP_REFERER']));
		}
		$userManager = &ivPool::get('userManager');
		$admin = $userManager->getUser('admin');
		$defaultUser = ('d033e22ae348aeb5660fc2140aec35850c4da997' === $admin->passwordHash);
		if ($defaultUser) {
			ivMessenger::add('error', '初次登录，用户名、密码均为admin 请登录后修改管理员密码！');
		}
		$this->view->assign('defaultUser', $defaultUser);
	}

	/**
	 * Log out
	 *
	 */
	function logoutAction()
	{
		ivAuth::authenticate('', '', false);
		ivMessenger::add('notice', 'Good bye!');
		$this->_redirect($_SERVER['HTTP_REFERER']);
	}

}
?>
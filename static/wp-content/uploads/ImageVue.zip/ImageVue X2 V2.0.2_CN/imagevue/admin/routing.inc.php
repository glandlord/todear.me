<?php
if (!defined('IV_PATH')) {
	exit(0);
}
?>
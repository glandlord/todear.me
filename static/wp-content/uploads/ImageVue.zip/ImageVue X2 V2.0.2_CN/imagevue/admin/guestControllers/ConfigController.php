<?php

class ConfigController extends ivController
{
	/**
	 * Default action (edit main config)
	 *
	 */
	function indexAction()
	{
		$crumbs = &ivPool::get('breadCrumbs');
		$crumbs->push('config', 'index.php?c=config');

		$xml = ivXml::readFromFile(CONFIG_FILE, DEFAULT_CONFIG_FILE);
		
		$this->view->assign('flatConfig', $xml->toFlatTree());
		$this->view->assign('langs', $this->_getLangs());

		if (isset($_COOKIE['ivconf'])) {
			$openedPanels = array_unique(array_explode_trim(',', $_COOKIE['ivconf']));
		} else {
			$openedPanels = array('config_settings3', 'config_controls35', 'config_audioplayer52', 'config_image64', 'config_thumbnails122', 'config_menu149', 'config_misc160', 'config_modules164', 'theme_style3', 'theme_controls23', 'theme_audioplayer36', 'theme_image40', 'theme_thumbnails89', 'theme_textpage121', 'theme_menu130', 'theme_modules159');
			setcookie('ivconf', implode(',', $openedPanels), time() + 365 * 86400);
		}
		$this->view->assign('openedPanels', $openedPanels);
	}
	
	/**
	 * Return list of langs file
	 *
	 * @return array
	 * @todo Kill this function
	 */
	function _getLangs()
	{
		$content = getContent(LANGS_DIR);
		$list = array();
		foreach ($content as $item) {
			if (ivFilepath::matchSuffix($item, array('xml'))) {
				$list[] = $item;
			}
		}
		sort($list);
		return $list;
	}
	
	/**
	 * Edit language
	 *
	 */
	function langAction()
	{
		$crumbs = &ivPool::get('breadCrumbs');
		$crumbs->push('config', 'index.php?c=config');
		$lang = $this->_getParam('name', 'english');
		if (!ctype_alnum($lang)) {
			ivMessenger::add('error', 'Use only alphanumeric symbols in language name');
			$this->_redirect('index.php?c=config');
		}
		$this->view->assign('lang', $lang);
		$crumbs->push($lang, 'index.php?c=config&amp;a=lang&amp;name=' . $lang);
		$configFile = LANGS_DIR . $lang . '.xml';

		$xml = ivXml::readFromFile($configFile, DEFAULT_LANG_FILE);
		
		$this->view->assign('flatConfig', $xml->toFlatTree());
		$this->view->assign('langs', $this->_getLangs());
	}

}
?>
<?php
/**
 * Random comparator class
 *
 */
class ivComparatorRandom extends ivComparator
{
	/**
	 * Compare two objects
	 *
	 * @param  mixed   $subject
	 * @param  mixed   $object
	 * @return integer
	 */
	function compare(&$subject, &$object)
	{
		return rand(0, 2) - 1;
	}

}
?>
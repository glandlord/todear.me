<?php
/**
 * Image file class
 *
 * @author McArrow
 */
class ivFileImage extends ivFile
{
	/**
	 * Properties
	 * @var array
	 */
	var $_properties = array(
		'name' => null,
		'path' => null,
		'date' => null,
		'size' => null,
		'width' => null,
		'height' => null,
		'type' => null
	);

	/**
	 * Initialize properties
	 *
	 * @access protected
	 */
	function _initProperties()
	{
		parent::_initProperties();
		$data = getimagesize($this->_path);
		$this->_setProperty('width', $data[0]);
		$this->_setProperty('height', $data[1]);
		$this->_setProperty('type', imageTypeToString($data[2]));
	}

	/**
	 * Initialize attributes
	 *
	 * @access protected
	 */
	function _initAttributes()
	{
		parent::_initAttributes();
		if ((!$this->getAttribute('title') || !$this->getAttribute('description')) && function_exists('exif_read_data')) {
			$exifData = @exif_read_data($file);
			if (!$this->getAttribute('title') && isset($exifData['DocumentName'])) {
				$title = trim($exifData['DocumentName']);
				if (!empty($title)) {
					$this->setAttribute('title', $title);
				}
			}
			if (!$this->getAttribute('description') && isset($exifData['ImageDescription'])) {
				$description = trim($exifData['ImageDescription']);
				if (!empty($description)) {
					$this->setAttribute('description', $description);
				}
			}
		}
	}
	
	/**
	 * Checks if path is image
	 *
	 * @static
	 * @param  string $path
	 * @return boolean
	 */
	function isSupported($path)
	{
		$supportedTypes = array(
			'image/gif',
			'image/jpeg',
			'image/tiff',
			'image/png'
		);
		if (parent::isSupported($path)) {
			$data = @getimagesize($path);
			return in_array($data['mime'], $supportedTypes);
		} else {
			return false;
		}
		return true;
	}
	
	/**
	 * Return path to thumbnail
	 *
	 * @param  boolean $force
	 * @return string
	 */
	function getThumb($force = false)
	{
		$conf = &ivPool::get('conf');
		$thumbPath = $this->_getThumbPath($conf->get('/config/imagevue/thumbnails/thumbnail/prefix'));
		if (!is_file($thumbPath) && $force) {
			$this->generateThumb();
		}
		return is_file($thumbPath) ? $thumbPath : parent::getThumb();
	}
	
	/**
	 * Generate thumb
	 *
	 */
	function generateThumb()
	{
		$conf = &ivPool::get('conf');
		$thumbPath = $this->_getThumbPath($conf->get('/config/imagevue/thumbnails/thumbnail/prefix'));
		$img = new ivImage($this->_path);
		if ($img->makeThumb(
			$conf->get('/config/imagevue/thumbnails/thumbnail/boxwidth'),
			$conf->get('/config/imagevue/thumbnails/thumbnail/boxheight'),
			$conf->get('/config/imagevue/thumbnails/thumbnail/quality'),
			$conf->get('/config/imagevue/thumbnails/thumbnail/resizetype'),
			$conf->get('/config/imagevue/thumbnails/thumbnail/keepaspect'),
			$conf->get('/config/imagevue/thumbnails/thumbnail/allowscaleup')
		)) {
			$img->write($thumbPath);
		}
	}
	
	/**
	 * Parses and returns exif data
	 *
	 * @return array
	 */
	function getExifData()
	{
		$exifParser = new ivExifParser();
		$exifData = $exifParser->parse($this->_path);
		return $exifData;
	}
	
	/**
	 * Returns self XML-node
	 *
	 * @param  boolean   $expanded
	 * @return ivXmlNode
	 */
	function &asXml($expanded = true)
	{
		$node = &parent::asXml();
		if ($expanded) {
			$exifData = $this->getExifData();
			if (is_array($exifData)) {
				$exifNode = &ivXmlNode::create('exif');
				foreach ($exifData as $key => $value) {
					$tag = &ivXmlNode::create(str_replace(array(' ', '(', ')'), array('_', '', ''), $key));
					$tag->setValue(htmlspecialchars($value));
					$exifNode->addChild($tag);
					unset($tag);
				}
				$node->addChild($exifNode);
			}
		}
		return $node;
	}

}
?>

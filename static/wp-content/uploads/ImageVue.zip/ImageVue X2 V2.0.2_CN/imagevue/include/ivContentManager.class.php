<?php
/**
 * Content manager class
 *
 * @author McArrow
 */
class ivContentManager
{
	/**
	 * An array of files' prefixes
	 * @var array
	 */
	var $_filePrefixes = array();

	/**
	 * Directory and file mode (dafaults to 0777 oct = 511 dec)
	 * @var integer
	 */
	var $_mode = 511;

	/**
	 * Constructor
	 *
	 */
	function ivContentManager()
	{
		$this->__construct();
	}

	/**
	 * Constructor
	 *
	 */
	function __construct()
	{
		$conf = &ivPool::get('conf');
		$this->_filePrefixes = $conf->get('/config/imagevue/settings/excludefilesprefix');
		$this->_mode = octdec($conf->get('/config/imagevue/settings/chmod'));
	}

	/**
	 * Creates new folder
	 *
	 * @param string $path
	 * @return boolean
	 */
	function create($path)
	{
		$result = $this->_create(ROOT_DIR . $path);
		return $result;
	}

	/**
	 * Copies file or folder
	 *
	 * @param  string $sourcePath
	 * @param  string $destPath
	 * @return boolean
	 */
	function copy($sourcePath, $destPath)
	{
		$result = $this->_copy(ROOT_DIR . $sourcePath, ivFilepath::normalizeDir(ROOT_DIR . $destPath));
		return $result;
	}

	/**
	 * Moves file or folder
	 *
	 * @param  string $sourcePath
	 * @param  string $destPath
	 * @return boolean
	 */
	function move($sourcePath, $destPath)
	{
		$result = $this->copy($sourcePath, ivFilepath::normalizeDir($destPath));
		$result &= $this->remove($sourcePath);
		return $result;
	}

	/**
	 * Removes file or folder
	 *
	 * @param string $path
	 */
	function remove($path)
	{
		$result = $this->_remove(ROOT_DIR . $path);
		return $result;
	}

	/**
	 * Creates new folder
	 *
	 * @param  string $path
	 * @return boolean
	 */
	function _create($path)
	{
		return mkdirRecursive($path, $this->_mode);
	}

	/**
	 * Copies file or folder
	 *
	 * @access private
	 * @param  string  $sourcePath
	 * @param  string  $destPath
	 * @return boolean
	 */
	function _copy($fullSourcePath, $fullDestPath)
	{
		if (is_file($fullSourcePath)) {
			$dir = ivFilepath::normalizeDir(dirname($fullSourcePath));
			$filename = ivFilepath::basename($fullSourcePath);
			foreach ($this->_filePrefixes as $prefix) {
				@copy($dir . $prefix . $filename, $fullDestPath . $prefix . $filename);
				@chmod($fullDestPath . $prefix . $filename, $this->_mode);
			}
			$result = @copy($dir . $filename, $fullDestPath . $filename);
			@chmod($fullDestPath . $filename, $this->_mode);
			$this->_copyFileNode($fullSourcePath, $fullDestPath, $filename);
			clearCache($dir);
			clearCache($fullDestPath);
			return $result;
		}
	}

	/**
	 * Removes file or folder
	 *
	 * @access private
	 * @param  string $path
	 * @return boolean
	 */
	function _remove($fullPath)
	{
		$result = false;
		if (is_file($fullPath)) {
			$dir = ivFilepath::normalizeDir(dirname($fullPath));
			foreach ($this->_filePrefixes as $prefix) {
				@unlink($dir . $prefix . ivFilepath::filename($fullPath) . '.jpg');
			}
			$basename = ivFilepath::basename($fullPath);
			$result = @unlink($dir . $basename);
			$this->_removeFileNode($fullPath, $basename);
		} elseif (is_dir($fullPath)) {
			$handle = opendir($fullPath);
			while (false !== ($file = readdir($handle))) {
				if (!in_array($file, array('.', '..'))) {
					$newFullPath = $fullPath . $file;
					if (is_file($newFullPath) && !ivFilepath::matchPrefix($file, $this->_filePrefixes)) {
						$this->_remove($newFullPath);
					} else {
						$this->_remove(ivFilepath::normalizeDir($newFullPath));
					}
				}
			}
			closedir($handle);
			$result = @rmdir($fullPath);
		}
		return $result;
	}

	function _copyFileNode($fullSourcePath, $fullDestPath, $filename)
	{
		$sourceXmlFile = ivFilepath::normalizeDir(dirname($fullSourcePath)) . 'folderdata.xml';
		$destXmlFile = $fullDestPath . 'folderdata.xml';

		$fileNode = null; 
		if (file_exists($sourceXmlFile)) {
			$srcXml = ivXml::readFromFile($sourceXmlFile);
			$fileNode = $srcXml->findByXPath("/folder/file[name=$filename]");
		};
		
		if (!$fileNode) {
			$fileNode = &ivXmlNode::create('file', array('name' => $filename));
		}
		
		$destXml = ivXml::readFromFile($destXmlFile);
		$folderNode = &$destXml->findByXPath('/folder');
		if (!$folderNode) {
			$folderNode = &ivXmlNode::create('folder');
			$destXml->setNodeTree($folderNode);
		}
		$oldFileNode = &$destXml->findByXPath("/folder/file[name=$filename]");
		if ($oldFileNode) {
			$oldFileNode = $fileNode;
		} else {
			$folderNode->addChild($fileNode);
		}
		$destXml->writeToFile();
	}

	function _removeFileNode($fullPath, $filename)
	{
		$dir = ivFilepath::normalizeDir(dirname($fullPath));
		$xmlFile = $dir . 'folderdata.xml';
		$fileNode = null; 
		if (file_exists($xmlFile)) {
			$xml = ivXml::readFromFile($xmlFile);
			$fileNode = &$xml->findByXPath("/folder/file[name=$filename]");
			if ($fileNode) {
				$xml->remove($fileNode);
				$xml->writeToFile();
			}
		};
	}
	
}
?>
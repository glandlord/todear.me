<?php
/**
 * File names and paths manipulations class
 *
 * @static
 */
class ivFilepath
{
	/**
	 * Ensures dir ends with slash
	 *
	 * @param  string $dir
	 * @return string
	 */
	function normalizeDir($dir)
	{
		return substr($dir, 0, 2) . str_replace('//', '/', substr($dir, 2) . '/');
	}

	/**
	 * Strips c:./../.../ etc
	 *
	 * @param  string $path
	 * @return string
	 */
	function safe($path)
	{
		$path = str_replace('\\', '/', $path);
		return preg_replace('/(\.+\/+|\/{2,}|.*\:\/*)/', '', trim(urldecode($path), '\./'));
	}

	/**
	 * Returns FILENAME's prefix (tn_) up to and including first occurrence of $separator = '_' or false
	 *
	 * @param  string $path
	 * @param  string $separator
	 * @return string
	 */
	function prefix($path, $separator='_')
	{
		$filename = ivFilepath::filename($path);
		$pos = strpos($filename, $separator);
		return (false === $pos ? false : substr($filename, 0, $pos + 1));
	}

	/**
	 * Returns path suffix (extension) after last occurence of $separator = '.' or false
	 *
	 * @param  string $path
	 * @param  string $separator
	 * @return string
	 */
	function suffix($path , $separator = '.')
	{
		$pos = strrpos($path, $separator);
		$slashPos1 = strrpos($path, '/');
		$slashPos2 = strrpos($path, '\\');
		return ((false === $pos || $slashPos1 > $pos || $slashPos2 > $pos) ? false : substr($path, $pos + 1));
	}

	/**
	 * Returns only FILENAME from path (no extension)
	 *
	 * @param  string $path
	 * @return string
	 */
	function filename($path)
	{
		if ('/' != substr($path, -1) && '\\' != substr($path, -1)) {
			return basename($path, '.' . ivFilepath::suffix($path));
		}
		return false;
	}

	/**
	 * Returns BASENAME (filename.ext)
	 *
	 * @return string
	 */
	function basename($path)
	{
		if ('/' != substr($path, -1) && '\\' != substr($path, -1)) {
			$pathParts = pathinfo($path);
			return $pathParts['basename'];
		}
		return false;
	}

	/**
	 * Returns DIRNAME (../dir/)
	 *
	 * @return string
	 */
	function directory($path)
	{
		if ('/' != substr($path, -1) && '\\' != substr($path, -1) && '' != $path) {
			$pathParts = pathinfo($path);
			return ivFilepath::normalizeDir(ivFilepath::safe($pathParts['dirname']));
		}
		return ivFilepath::normalizeDir($path);
	}

	/**
	 * Removes ./../... crap
	 *
	 * @param  string $path
	 * @return string
	 */
	function safeDirectory($path)
	{
		return ivFilepath::normalizeDir(ivFilepath::safe(ivFilepath::directory($path)));
	}

	/**
	 * Checks if file suffix is in array
 	 *
 	 * @param  string  $filename
 	 * @param  array   $extArray
 	 * @param  string  $separator
 	 * @return boolean
 	 */
	function matchSuffix($filename, $extArray, $separator = '.')
	{
		return in_array(strtolower(ivFilepath::suffix($filename, $separator)), $extArray);
	}

	/**
	 * Checks if file PREFIX is in array
 	 *
 	 * @param  string  $filename
 	 * @param  array   $prefArray
 	 * @param  string  $separator
 	 * @return boolean
 	 */
	function matchPrefix($filename, $prefArray)
	{
		foreach ($prefArray as $prefix) {
			if (strtolower(ivFilepath::prefix($filename)) == $prefix) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Returns directory name, i.e. birds for content/animals/birds/
 	 *
 	 * @param  string  $path
 	 * @return string
 	 */
	function getDirectoryName($path)
	{
		$path = str_replace('\\', '/', $path);
		$dirs = array_explode_trim('/', ivFilepath::directory($path));
		if (!is_array($dirs)) {
			return '';
		}
		return end($dirs);
	}

}
?>
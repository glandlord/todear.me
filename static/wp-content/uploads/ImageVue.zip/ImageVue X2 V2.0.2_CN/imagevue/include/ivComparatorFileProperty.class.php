<?php
/**
 * File property comparator
 *
 * @author McArrow
 */
class ivComparatorFileProperty extends ivComparator
{
	/**
	 * Property name
	 * @var string
	 */
	var $_property = null;
	
	/**
	 * Constructor
	 *
	 * @param  string $property
	 */
	function ivComparatorFileProperty($property)
	{
		$this->__construct($property);
	}

	/**
	 * Constructor
	 *
	 * @param string $property
	 */
	function __construct($property)
	{
		$this->_property = $property;
	}

	/**
	 * Compare two files by property
	 *
	 * @param  ivFSItem $item1
	 * @param  ivFSItem $item2
	 * @return integer
	 */
	function compare(&$item1, &$item2)
	{
		$path1 = $item1->_path;
		$path2 = $item2->_path;
		switch ($this->_property) {
			case 'name':
				return parent::compare(strtolower(basename($path1)), strtolower(basename($path2)));
				break;
			case 'size':
				return parent::compare(filesize($path1), filesize($path2));
				break;
			case 'date':
				return parent::compare(filectime($path1), filectime($path2));
				break;
		}
		return parent::compare($item1->getProperty($this->_property), $item2->getProperty($this->_property));
	}

}
?>
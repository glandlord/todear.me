<?php
/**
 * String XML node class
 *
 * @author McArrow
 */
class ivXmlNodeString extends ivXmlNode
{}
?>
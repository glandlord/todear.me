<?php
/**
 * The main template file.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * 这是index
 *
 *
 *          ::.--.-.::
 *          :( (    ):::::  东边日出西边雨 
 *          (_,  \ ) ,_)::  道是无晴却有情       |
 *          :::-'--`--:::::::: ~~|     ,       \ _ /
 *          ::::::::::::::::::: ,|`-._/|   -==  (_)  ==-
 *          ::::::::^^::::::::.' |   /||\      /   \
 *          ::::::^^::::::::.'   | ./ ||`\       |
 *          :::::::::::::::/ `-. |/._ ||  \
 *          ::::::::::::::|      ||   ||   \
 *          ~~=~_~^~ =~ \~~~~~~~'~~~~'~~~~/~~`` ~=~^~
 *          ~^^~~-=~^~ ^ `--------------'~^~=~^~_~^=~^~
 *
 * @author winy <admin@winysky.com>
 * @link http://winysky.com/
 */
?>
<?php get_header(); ?>
  <div id="main">
        <div id="top">
		<div class="main_view">
    <div class="window">
 
              <ul class="image_reel">
  <?php $new_query = new WP_Query('showposts=3');while ($new_query->have_posts()) : $new_query->the_post();$do_not_duplicate[] = $post->ID;?>
    	<li class="slider_content">
	
	<h2><a href="<?php the_permalink(); ?>" rel="bookmark inlinks permalink" title="<?php the_title_attribute(); ?>"><?php winyexcerpt(70, '...', 'title'); ?></a></h2>
	<div class="postinfo">
		<?php time_diff( $time_type = 'post' ); ?>&nbsp;|&nbsp;<?php the_category(',') ?>&nbsp;|&nbsp;<?php if(function_exists('the_views')) { the_views(); } ?>&nbsp;|&nbsp;<?php comments_popup_link('来抢沙发', '1  条评论', '%  条评论'); ?><?php edit_post_link(__('编辑'), ' | ', ''); ?>
	</div>
	<div class="sliderimg">
<?php winypostimg($imagestype='slider');?>
</div>

	<?php winyexcerpt(430); ?>

  </li> 
  <?php endwhile; ?>
   <?php $new_query = new WP_Query('showposts=1&orderby=rand&post_not_in=array($do_not_duplicate)');while ($new_query->have_posts()) : $new_query->the_post();$do_not_duplicate[] = $post->ID;?>
   	<li class="slider_content">
	<h2><a href="<?php the_permalink(); ?>" rel="bookmark inlinks permalink" title="<?php the_title_attribute(); ?>"><?php winyexcerpt(45, '...', 'title'); ?></a></h2>
	<div class="postinfo">
		<?php time_diff( $time_type = 'post' ); ?>&nbsp;|&nbsp;<?php the_category(',') ?>&nbsp;|&nbsp;<?php if(function_exists('the_views')) { the_views(); } ?>&nbsp;|&nbsp;<?php comments_popup_link('来抢沙发', '1  条评论', '%  条评论'); ?><?php edit_post_link(__('编辑'), ' | ', ''); ?>
	</div>
	<div class="sliderimg">
<?php winypostimg($imagestype='slider');?>
</div>

	<?php winyexcerpt(250); ?>

  </li> 
  <?php endwhile; wp_reset_query();?>
  
  </ul> 

    </div>
    <div class="paging">
        <a href="javascript:void(0);" title="1">1</a>
        <a href="javascript:void(0);" title="2">2</a>
        <a href="javascript:void(0);" title="3">3</a>
        <a href="javascript:void(0);" title="4">4</a>
    </div>
</div>
<div class="clear"></div>        
<div class="showdow_bl">
<div class="showdow_br"><div class="showdow_b"></div></div></div>
<script type="text/javascript">

jQuery(document).ready(function() {

	//Set Default State of each portfolio piece
	$(".paging").show();
	$(".paging a:first").addClass("active");
		
	//Get size of images, how many there are, then determin the size of the image reel.
	var imageWidth = "800";
	var imageSum = $(".image_reel img").size();
	var imageReelWidth = imageWidth * imageSum;
	
	//Adjust the image reel to its new size
	$(".image_reel").css({'width' : imageReelWidth});
	
	//Paging + Slider Function
	rotate = function(){	
		var triggerID = $active.attr("title") - 1; //Get number of times to slide
		var image_reelPosition = triggerID * imageWidth; //Determines the distance the image reel needs to slide

		$(".paging a").removeClass('active'); //Remove all active class
		$active.addClass('active'); //Add active class (the $active is declared in the rotateSwitch function)
		
		//Slider Animation
		$(".image_reel").animate({ 
			left: -image_reelPosition
		}, 800);
		
	}; 
	
	//Rotation + Timing Event
	rotateSwitch = function(){		
		play = setInterval(function(){ //Set timer - this will repeat itself every 3 seconds
			$active = $('.paging a.active').next();
			if ( $active.length === 0) { //If paging reaches the end...
				$active = $('.paging a:first'); //go back to first
			}
			rotate(); //Trigger the paging and slider function
		}, 5000); //Timer speed in milliseconds (3 seconds)
	};
	
	rotateSwitch(); //Run function on launch
	
	//On Hover
	$(".image_reel li").hover(function() {
		clearInterval(play); //Stop the rotation
	}, function() {
		rotateSwitch(); //Resume rotation
	});	
	
	//On Click
	$(".paging a").click(function() {	
		$active = $(this); //Activate the clicked paging
		//Reset Timer
		clearInterval(play); //Stop the rotation
		rotate(); //Trigger rotation immediately
		rotateSwitch(); // Resume rotation
		return false; //Prevent browser jump to link anchor
	});	
	
});
</script>


</div>
<div id="quick" >
	<ul>
	<?php wp_list_categories('orderby=name&title_li=&style=list'); ?></ul>
	
	<div class="clear"></div>
</div> 
<div id="middle">
<div id="content-post" > 

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php if (in_array($post->ID, $do_not_duplicate)) continue;update_post_caches($posts); ?>
<div id="post-<?php the_ID(); ?>" class="post">

	<h3><a href="<?php the_permalink() ?>" rel="bookmark" title="查看文章: <?php the_title_attribute(); ?>"><?php winyexcerpt(70, '...', 'title'); ?></a></h3>
	<div class="postmeta">
		<span class="alignleft"><?php the_category(',') ?>&nbsp;|&nbsp;<?php if(function_exists('the_views')) { the_views(); } ?>&nbsp;|&nbsp;<?php comments_popup_link('来抢沙发', '1  条评论', '%  条评论'); ?><?php edit_post_link(__('编辑'), ' | ', ''); ?></span><span class="alignright">-<?php time_diff( $time_type = 'post' ); ?></span>
	</div>
<div class="postentry">
<?php winyexcerpt(405); ?>
</div>
<div class="postimg">
<?php winypostimg();?>
</div>
<div class="clear"></div>
</div>
<?php endwhile; else: ?>
	
	<?php header("HTTP/1.1 404 Method Not Allowed");
header("Content-type: text/plain");
exit;?>
<?php endif; ?>


</div>
<div id="pagenavi"><?php pagenavi();  ?></div></div>
<?php get_footer(); ?>  
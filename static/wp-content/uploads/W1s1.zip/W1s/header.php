<?php
// no direct access
defined('WINYSKY') or die('Restricted access -- WINYSKY ');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" xml:lang="zh">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<title><?php
	/*
	 * Print the <title> tag based on what is being viewed.
	 */
	global $page, $paged;

	wp_title( '|', true, 'right' );

	// Add the blog name.
	bloginfo( 'name' );

	// Add the blog description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";

	// Add a page number if necessary:
	if ( $paged >= 2 || $page >= 2 )
		echo ' | ' . sprintf( __( 'Page %s', 'twentyten' ), max( $paged, $page ) );

	?></title>
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />
<!--[if IE]>
<link rel="stylesheet" type="text/css" media="screen" href="<?php bloginfo('template_url'); ?>/ie6.css" />
<![endif]--> 
<link rel="shortcut icon" href="<?php bloginfo('url'); ?>/favicon.ico"  type="image/x-ico"/>
<script type="text/javascript">/* <![CDATA[ */var base="<?php bloginfo('url'); ?>"; var themeurl="<?php echo get_bloginfo('template_directory') . '/';?>";css_string = '#main{-moz-border-radius:0 0 10px 10px;-webkit-border-radius:0 0 10px 10px;border-radius:0 0 10px 10px;}';css_string += 'a:link, a:visited ';css_string += '{-webkit-transition: all 0.8s ease-in-out;}';css_string += '::-moz-selection,::selection';css_string += '{background-color: #7e5393; color: #fff;}';css_string += '.paging a.active,.readmore a, .readmore a:hover, .comment, .avatar,#author, #email, #url,#submit_mail,#ajaxnav a,.postimg,#box_content,blockquote,.barlist,#footbar,pre,code,.nbox a,.nbox,#saytooltip,#submit_comment,#submit,#rc_submit, input[type="text"],textarea,#smelislist';css_string += '{-moz-border-radius: 5px; -khtml-border-radius: 5px; -webkit-border-radius: 5px;border-radius: 5px;}';css_string += 'pre';css_string += '{-moz-box-shadow: rgba(50,50,50,1) 1px 4px 7px; -webkit-box-shadow: rgba(50,50,50,1) 1px 4px 7px; -khtml-box-shadow: rgba(50,50,50,1) 1px 4px 7px; box-shadow: rgba(50,50,50,1) 1px 4px 7px;}';css_string += '.mostactive img,#smelislist';css_string += '{-moz-box-shadow: rgba(0,0,0,.8) 1px 7px 12px; -webkit-box-shadow: rgba(0,0,0,.8) 1px 7px 12px; -khtml-box-shadow: rgba(0,0,0,.8) 1px 7px 12px; box-shadow: rgba(0,0,0,.8) 1px 7px 12px;}';css_string += '#submit_comment,#submit,#submit_mail,#rc_submit';css_string += '{-moz-box-shadow:0 1px 1px #AAAAAA;-webkit-box-shadow:0 1px 1px #AAAAAA;}';css_string += 'input:focus,textarea:focus,#email:focus, #url:focus, #author:focus';css_string += '{-moz-box-shadow: 0 0 8px #52A8EC; -webkit-box-shadow: 0 0 8px #52A8EC;}';document.write('<style type="text\/css">' + css_string + '<\/style>');/* ]]> */</script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jQuery.js"></script> 
<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>-->
<!-- PNG -->
<!--[if lt IE 7]>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/pngfix.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('.boxCaption,.top_box,.logo');
</script>
<![endif]-->
<?php wp_head(); ?>
</head>
<body  <?php body_class(); ?>>

		<div id="wrapper">
			<div id="container"<?php if(!is_bot()){ echo ' style="opacity:0;"';}?>>			
				<div id="header" >
				   <div id="logo">
				   <?php $hhead = is_home() ? 'h1' : 'div'; ?><<?php echo $hhead; ?> id="site-title"><a rel="bloghome" href="<?php echo get_option('home'); ?>/" title="Home"><?php bloginfo('name') ?></a></<?php echo $hhead; ?>><div id="description"><?php bloginfo('description') ?></div>
					</div>
					<div id="headbar">
						<div id="box_corner"></div>
						<div id="box_content">
						<?php if(!is_bot()) :?>
						<?php welcome_msg();?>
						<?php endif;?>
						</div>
					</div>
					<div id="menu">
							<ul id="navmenu">
								<li class="home <?php echo (is_home() || is_single()) ? 'current_page_item' : 'page_item'; ?>"><a href="<?php echo get_option('Home'); ?>/" title="首页">首页</a></li>
				<?php wp_list_pages('depth=1&title_li=0&sort_column=menu_order'); ?>
							</ul> 
							<div id="search">
				   <?php include (TEMPLATEPATH . "/searchform.php"); ?>
				   </div>
					</div> <!-- end of  menu -->
				   <div id="rss">
				   <a id="feed" href="<?php bloginfo('rss2_url'); ?>" rel="nofollow" title="订阅小站">RSS Feed</a>
				   </div>
      			<div class="clear"></div>
				</div> <!-- end of header -->
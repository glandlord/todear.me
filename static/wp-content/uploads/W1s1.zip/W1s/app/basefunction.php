<?php
/**
 * basic function 
 */
 // no direct access
defined('WINYSKY') or die('Restricted access -- WINYSKY ');

/**
 * 错误泡泡
 *
 * 用于抛出错误
 * 实现$s的多变
 * 摘自著名主题 k2
 * 修改了参数类型,更方便使用!
 *
 * @since 1.0
 */
function fail($s) {
	header('HTTP/1.0 403 Forbidden');
	header('Content-Type: text/plain');
	if(is_string($s)){
		die($s);
	}else{
		$s;
		die;
	}
}
/**
 * 通过USER_Agent判断是否为机器人.
 * Edit by winy 10.01.28
 * @return Boolean
 */
function is_bot(){
	$bots = array('Baiduspider1'=>'Baiduspider','Baiduspider2'=>'Baiduspider+','Google Bot1' => 'googlebot', 'Google Bot2' => 'google', 'Google AdSense' => 'Mediapartners', 'MSN' => 'msnbot', 'Yahoo Bot1' => 'yahoo', 'Yahoo Bot2' => 'Yahoo! Slurp','Yahoo Bot3' => 'Yahoo! Slurp China','YodaoBot' => 'YodaoBot','iaskspider' => 'iaskspider','Sogou web spider' => 'Sogou web spider','Sogou Push Spider' => 'Sogou Push Spider','Sosospider' => 'Sosospider','Alex' => 'ia_archiver', 'Bot'=>'bot','Spider'=>'spider','for_test'=>'sFirefox');
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	foreach ($bots as $name => $lookfor) {
		if (stristr($useragent, $lookfor) !== false) {
			return true;
			break;
		}
	}
}



/* UTF-8 substr() for none mb_substr() */
if ( !function_exists('mb_substr') ) {
  function mb_substr( $str, $start, $length, $encoding ) {
    return preg_replace( '#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,' . $start . '}'.
    '((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,' . $length . '}).*#s', '$1', $str);
  }
}


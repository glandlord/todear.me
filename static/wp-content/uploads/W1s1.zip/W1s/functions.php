<?php
/**
 * W1 functions and definitions
 * 主题初始化，设定一些参数
 */
 
// no direct access
defined('ABSPATH') or die('Restricted access -- WINYSKY ');
// -- BASE Define BEGIN ----------------------------------------

/* PHP warning message */
error_reporting(E_ALL & ~E_NOTICE); // 偵錯用

/* 限制直接访问的定义*/
define('WINYSKY', 'WINYSKY');
// app dir
define('winysky_app', TEMPLATEPATH.'/app');
// debug - if true the errors will display below footer when admin login
//define('winysky_DEBUG', true);
//
define('WINYSKY', 'WINYSKY');

/**
 * include all PHP script
 * @param string $dir
 * @return unknown_type
 */
function IncludeAll($dir){
	$dir = realpath($dir);
	if($dir){
		$files = scandir($dir);
		sort($files);
		foreach($files as $file){
			if($file == '.' || $file == '..'){
				continue;
			}elseif(preg_match('/\.php$/i', $file)){
				include_once $dir.'/'.$file;
			}
		}
	}
}

// include functions by yinheli
IncludeAll( winysky_app );




?>

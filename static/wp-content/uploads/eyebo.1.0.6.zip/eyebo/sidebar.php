<div id="sidebar">
<ul>
<?php
global $user_ID, $user_identity;
get_currentuserinfo();
if (!$user_ID):
?>
<li class="userpanel">
<h2><?php _e('Login', 'eyebo'); ?></h2>
<div class="login">
<form name="loginform" id="loginform" action="<?php echo get_settings('siteurl'); ?>/wp-login.php" method="post">
<label>
<input class="textinput" type="text" onclick="value=''" name="log" id="log" value="<?php _e('Username', 'eyebo'); ?>" size="20" tabindex="7" />
</label>
<label>
<input class="textinput" type="password" onclick="value=''" name="pwd" id="pwd" value="<?php _e('Password', 'eyebo'); ?>" size="20" tabindex="8" />
</label>
<label>
<input type="submit" class="button" name="submit" value="" tabindex="10" />
</label>
<label style="display:none;">
<input type="checkbox" name="rememberme" value="forever" tabindex="9" class="remember"/>
</label>
<input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>"/>
</form></div>
</li>
<?php
else:
?>
<li class="userpanel">
<h2><?php _e('Logged in as ', 'eyebo'); ?><?php echo $user_identity; ?></h2>
<ul>
<li class="panelhome"><a href="<?php echo admin_url() ?>"><?php _e('Dashboard', 'eyebo'); ?></a></li>
<?php if ( current_user_can( 'edit_post', $post_id ) ) : ?>
<li class="whitepost"><a href="<?php echo admin_url('post-new.php') ?>"><?php _e('Write an article', 'eyebo'); ?></a></li>
<?php endif ?>
<li class="personal"><a href="<?php echo admin_url('profile.php') ?>"><?php _e('Profile and personal options', 'eyebo'); ?></a></li>
<li><a href="<?php echo wp_logout_url(); ?><?php echo '&redirect_to='.$_SERVER['REQUEST_URI']; ?>"><?php _e('Logout', 'eyebo'); ?></a></li>
</ul></li>
<?php endif; ?>
<?php if (is_single()) { ?>
<li class="about">
<h2><?php _e('Related posts', 'eyebo'); ?></h2>
<?php if(function_exists('wp23_related_posts')) {?>
<?php wp23_related_posts('wp_rp_title='); }else{?>
<?php eyebo_get_related_posts(); }?>
</li>
<?php } ?>
<?php if (is_search()) { ?>
<?php } ?>
<?php if (is_404()) { ?>
<?php } ?>
<?php /* If this is a category archive */ if (is_category()) { ?>
<li class="about"><h2><?php _e('Posts in this category', 'eyebo'); ?></h2>
<?php 
global $wp_query;
$cat_id = $wp_query->get_queried_object_id();
$posts = get_posts("category=".$cat_id."&numberposts=10"); ?>
<?php if( $posts ) : ?>
<ul><?php foreach( $posts as $post ) : setup_postdata( $post ); ?>
<li>
<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>
</li> 
<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
<?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
<?php /* If this is an author archive */ } elseif (is_author()) { ?>
<?php /* If this is the archives page */ } elseif (is_page()) { ?>
<?php wp_list_pages('title_li=<h2>'.__('Child pages','eyebo').'</h2>&child_of='.$post->ID.''); ?>
<?php } ?>
<?php if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar() ) : ?><!-- Categories code--> 
<?php wp_list_categories('orderby=name&title_li=<h2>'.__('Categories','eyebo').'</h2>');?>
<!-- Categories end-->
<?php if (is_home()){ ?>
<!-- Most commented post code.-->
<?php eyebo_most_commented_posts(); ?>
<!-- Most commented post end-->
<?php }?>
<?php if (!is_home()){ ?> 
<!--Recent entries code You can change the number-->
<li class="recent_entries"><h2><?php _e('Recent entries','eyebo') ?></h2>
<ul>
<?php $recent_posts = get_posts('numberposts=6');
foreach( $recent_posts as $post ) : ?>
<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
<?php endforeach; ?>
</ul></li>
<!--Recent entries code end-->
<?php }?>
<!--Random posts code-->
<li class="random_posts"><h2><?php _e('Random posts','eyebo') ?></h2>
<ul>
<?php $rand_posts = get_posts('numberposts=6&orderby=rand');
foreach( $rand_posts as $post ) : ?>
<li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
<?php endforeach; ?>
</ul></li>
<!--Random posts code end-->
<!--Meta code-->
<li id="meta"><h2><?php _e('Meta'); ?></h2>
			<ul>
                <?php wp_register(); ?>
					<li><a href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Transitional', 'eyebo'); ?>"><?php _e('Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr>', 'eyebo'); ?></a></li>
					<li><a href="http://gmpg.org/xfn/"><abbr title="<?php _e('XHTML Friends Network', 'eyebo'); ?>"><?php _e('XFN', 'eyebo'); ?></abbr></a></li>					<li><a href="http://wordpress.org/" title="<?php _e('Powered by WordPress, state-of-the-art semantic personal publishing platform.', 'eyebo'); ?>">WordPress</a></li>
                    <li class="rss"><a href="<?php bloginfo('rss2_url'); ?>">(RSS2.0)</a></li>
				<li class="atom"><a href="<?php bloginfo('atom_url'); ?>">(Atom)</a></li>
					<?php wp_meta(); ?>
			</ul>
				</li>
<!--Meta code end-->
<?php if (is_home()){ ?>
<!-- Blogroll code,You can change the category id which you want-->
<?php wp_list_bookmarks('category=2');?>
<!-- Blogroll code end-->
<?php }?>
<?php endif; ?>
</ul>
<div class="greybox">
<!--Please leave the theme credit. -->
<small><a href="http://wordpress.org/" target="_blank">Wordpress</a> theme "<a href="http://www.cisvi.com/bo/eyebo-952/" title="Eyebo Wordpress Theme">Eyebo</a>" by <a href="http://www.cisvi.com" title="cisvi">Zern</a>.</small></div></div>
<!-- end sidebar -->
<div id="footer2"> 
  <div class="blackbar">
    <ul class="nav">
    <li><a href="<?php echo get_option('home'); ?>/" title="<?php _e('Home', 'eyebo'); ?>"><?php _e('Home', 'eyebo'); ?></a></li>
         <?php wp_list_pages('depth=1&title_li='); ?><li><a href="#top"><?php _e('Top &uarr;', 'eyebo'); ?></a></li>
    </ul>
<a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a><?php _e(' &copy;  Copyright 2009, All Rights Reserved.', 'eyebo'); ?></div>
</div>
<!-- end footer -->
</div>
<!-- end wrapper -->
<?php wp_footer(); ?>
</body></html>
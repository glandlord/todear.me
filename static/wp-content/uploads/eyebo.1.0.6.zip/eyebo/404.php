<?php get_header(); ?>
<div class="postmain">
  <p  class="information"><?php _e('404 Not Found', 'eyebo'); ?></p>
</div>
<!-- end post -->
<?php include (TEMPLATEPATH . '/sidebar.php'); ?>
<?php get_footer(); ?>
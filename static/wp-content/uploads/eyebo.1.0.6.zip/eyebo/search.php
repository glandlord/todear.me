<?php get_header(); ?>
<div class="postmain">
  <?php if (have_posts()) : ?>
  <p class="information"><?php _e('Search Results', 'eyebo'); ?></p>
<script type="text/javascript">
 var descriptionint="<?php _e('Font size:','eyebo'); ?>";
</script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/fontsize-switcher.js"></script>
<div id="maincontent">
numberposts
  <?php while (have_posts()) : the_post(); ?>
  <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
  <div class="posttitle"><span class="edit-right"><?php edit_post_link(__('Edit', 'eyebo'), '', ''); ?></span><h1><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link to', 'eyebo'); ?><?php the_title(); ?>"><?php the_title(); ?></a></h1></div>
  <div class="postcontent"><?php the_content(__('Read the rest of this entry &raquo;', 'eyebo')); ?>
  <div class="posttag"><?php the_tags(__('Tags:', 'eyebo') . ' ', ', ', ''); ?></div>
  </div>
  <div class="postmetadata"><small><span class="comments-right">
  <?php comments_popup_link(__('No Comments &#187;', 'eyebo'), __('1 Comment', 'eyebo'), __('% Comments', 'eyebo'), '', __('Comments Closed', 'eyebo' )); ?></span>
<?php the_time(__('Y-m-d (D) G:i', 'eyebo')) ?> | <?php printf(__('Posted in %s', 'eyebo'), get_the_category_list(', ')); ?> | <?php the_author() ?></small></div></div>
  <?php endwhile; ?>
  </div>
  <?php $older_page = get_next_posts_link(false, '');
	$newer_page = get_previous_posts_link(false, '');
	?><?php if($newer_page || $older_page) :?>
    <div class="navigation">
      <?php if(function_exists('wp_pagenavi')) {?><?php wp_pagenavi(); }else{ ?>
    <div class="alignleft">
	<?php next_posts_link(__('&laquo; Older Entries', 'eyebo')) ?>
    </div>
    <div class="alignright">
<?php previous_posts_link(__('Newer Entries &raquo;', 'eyebo')) ?>
    </div><?php } ?></div><?php endif; ?>
    <!-- end navigation -->
  <?php else : ?>
  <p class="information"><?php _e('Hmm... Nothing Found. Make sure all words are spelled correctly.', 'eyebo'); ?></p>
    <?php endif; ?>
  </div>
<!-- end post -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
<?php get_header(); 
if ( is_attachment() ) :
	$older_post = &get_post($GLOBALS['post']->post_parent);
	else :
	$older_post = get_previous_post(false, '');
	endif;
	$newer_post = get_next_post(false, '');
?>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<div class="postmain" id="post-<?php the_ID(); ?>">
    <?php if($newer_post || $older_post ) :?>
    <div class="navigation">
    <div class="alignleft"><?php next_post_link('&raquo; %link'); ?></div>
    <div class="alignright"><?php previous_post_link('&laquo; %link'); ?></div>
  </div>
  <?php	endif; ?>
  <script type="text/javascript">
 var descriptionint="<?php _e('Font size:','eyebo'); ?>";
</script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/fontsize-switcher.js"></script>
      <div class="posttitle"><span class="edit-right"><?php edit_post_link(__('Edit', 'eyebo'), '', ''); ?></span><h1><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link to', 'eyebo'); ?><?php the_title(); ?>"><?php the_title(); ?></a></h1></div><div class="postcontent" id="maincontent">
  <?php the_content(__('Read the rest of this entry &raquo;', 'eyebo')); ?>
  <?php wp_link_pages(array('before' => __('<div class="navigation"><p><strong>Pages:</strong>', 'eyebo'), 'after' => '</p></div>', 'next_or_number' => 'number')); ?>
  <div class="posttag"><?php the_tags(__('Tags:', 'eyebo') . ' ', ', ', ''); ?></div>
  </div>
  <div class="postmetadata"><small><span class="comments-right"><?php if (('open' == $post-> comment_status) && ('open' == $post->ping_status)) {
							// Both Comments and Pings are open ?>
							<?php printf(__('<a href="#respond">leave a response</a>', 'eyebo'), trackback_url(false)); ?>

						<?php } elseif (!('open' == $post-> comment_status) && ('open' == $post->ping_status)) {
							// Only Pings are Open ?>
							<?php printf(__('Comments closed, you can <a href="%s" rel="trackback">trackback</a>', 'eyebo'), trackback_url(false)); ?>

						<?php } elseif (('open' == $post-> comment_status) && !('open' == $post->ping_status)) {
							// Comments are open, Pings are not ?>
							<?php printf(__('<a href="#respond">leave a Comment</a>', 'eyebo')); ?>

						<?php } elseif (!('open' == $post-> comment_status) && !('open' == $post->ping_status)){
							// Neither Comments, nor Pings are open ?>
							<?php _e('Comments and pings are currently closed.', 'eyebo'); }?></span>
<?php the_time(__('Y-m-d (D) G:i', 'eyebo')) ?> | <?php printf(__('Posted in %s', 'eyebo'), get_the_category_list(', ')); ?> | <?php the_author() ?></small></div>
	<!-- end entry -->
<?php comments_template('', true); ?>
</div><!-- end post -->
	<?php endwhile; else: ?>
    <div class="postmain">
<p  class="information"><?php _e('Sorry, no posts matched your criteria.', 'eyebo'); ?></p>
</div>
<?php endif; ?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
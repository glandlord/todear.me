<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<h2><?php _e('Search for:', 'eyebo'); ?></h2>
<div class="searchright"><input type="text" value="<?php the_search_query(); ?>" name="s" id="s" />
<input type="submit" id="searchsubmit" value="<?php _e('Search', 'eyebo'); ?>" />
</div>
</form>
<?php
/*
Template Name: Archives
*/
?>
<?php get_header(); ?>
<div class="postmain">
<script type="text/javascript">
 var descriptionint="<?php _e('Font size:','eyebo'); ?>";
</script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/fontsize-switcher.js"></script>
  <div class="posttitle"><h1><?php _e('Archives', 'eyebo'); ?></h1></div>
   <div class="postcontent" id="maincontent">
  <strong><?php _e('Archives by Month:', 'eyebo'); ?></strong>
  <ul>
    <?php wp_get_archives('type=monthly'); ?>
  </ul>
  <div class="line"></div>
  <strong><?php _e('Archives by Subject:', 'eyebo'); ?></strong>
  <ul>
    <?php wp_list_cats(); ?>
  </ul>
  </div>
</div>
<!-- end post -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>

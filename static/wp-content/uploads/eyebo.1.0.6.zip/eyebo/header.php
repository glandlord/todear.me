<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php bloginfo('name'); ?> &raquo;<?php if (is_home()) { echo _e('Home', 'eyebo'); } elseif (is_404()) { echo _e('404 Not Found', 'eyebo'); } elseif (is_category()) { echo _e('Category', 'eyebo'); wp_title(''); } elseif (is_search()) { echo _e('Search Results', 'eyebo'); } elseif ( is_day() || is_month() || is_year() ) { echo _e('Archives', 'eyebo'); wp_title(''); } else { echo wp_title(''); } ?> </title> 
<!-- the theme css by zern -->
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php printf(__('%s RSS Feed', 'eyebo'), get_bloginfo('name')); ?>" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php printf(__('%s Atom Feed', 'eyebo'), get_bloginfo('name')); ?>" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>

</head>
<body>
<div id="wrapper">
<a name="top"></a>
<div id="header">
<div class="navsear"><ul class="nav"><li class="navhome"><a href="<?php echo get_option('home'); ?>/" title="<?php _e('Home', 'eyebo'); ?>"><?php _e('Home', 'eyebo'); ?></a></li><?php wp_list_pages('depth=1&title_li='); ?></ul><div class="searchdiv"><div id="search_head">
  <form method="get" id="search_form" action="<?php bloginfo('home'); ?>/">
    <input class="textinput" type="text" name="s" onclick="value=''" id="s_head" value="<?php _e('Search', 'eyebo'); ?>"/>
    <input type="hidden" id="searchsubmit_head" value="Search" />
  </form>
</div></div></div>
<!--if you use your logo--> 
<?php /*?>	  <h1><a href="<?php echo get_option('home'); ?>/"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/logo.gif" alt="<?php bloginfo('name'); ?>"/></a></h1><?php */?>
<!--if you use title & description-->
     <h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
     <div class="description"><?php bloginfo('description'); ?></div>
     <!--end use-->
<div id="headerstripe"></div>
<div class="mainpic"><img src="<?php bloginfo('template_directory'); ?>/images/headers/header.jpg" alt="top head"/></div>
</div>
<!-- end header -->
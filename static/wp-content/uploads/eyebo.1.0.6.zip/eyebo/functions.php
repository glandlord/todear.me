<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget' => '</li>',
        'before_title' => '<h2 class="widgettitle">',
        'after_title' => '</h2>',
    ));

load_theme_textdomain('eyebo');
?>
<?php 
function eyebo_get_related_posts() {
	global $wpdb, $post;
		
	if(!$post->ID){return;}
	$now = current_time('mysql', 1);
	$tags = wp_get_post_tags($post->ID);

	//print_r($tags);
	
	$taglist = "'" . $tags[0]->term_id. "'";
	
	$tagcount = count($tags);
	if ($tagcount > 1) {
		for ($i = 1; $i <= $tagcount; $i++) {
			$taglist = $taglist . ", '" . $tags[$i]->term_id . "'";
		}
	}
	$q = "SELECT p.ID, count(t_r.object_id) as cnt FROM $wpdb->term_taxonomy t_t, $wpdb->term_relationships t_r, $wpdb->posts p WHERE t_t.taxonomy ='post_tag' AND t_t.term_taxonomy_id = t_r.term_taxonomy_id AND t_r.object_id  = p.ID AND (t_t.term_id IN ($taglist)) AND p.ID != $post->ID AND p.post_status = 'publish' AND p.post_date_gmt < '$now' GROUP BY t_r.object_id ORDER BY cnt DESC, p.post_date_gmt DESC LIMIT 8;";
	//echo $q;
	$related_posts =$wpdb->get_results($q);
	$output = "";
	if (!$related_posts){
			$wp_no_rp_text= __("No Related Post",'eyebo');
			$output  .= '<li>'.$wp_no_rp_text .'</li>';
	}		
	foreach ($related_posts as $related_post ){
		$output .= '<li>';
		$output .=  '<a href="'.get_permalink($related_post->ID).'" title="'.get_the_title($related_post->ID).'">'.get_the_title($related_post->ID).'</a>';	
		$output .=  '</li>';
	}
	$output = '<ul class="related_post">' . $output . '</ul>';
	echo $output;
}
function eyebo_get_most_commented_posts($limitclause="") {
	global $wpdb; 
    $q = "SELECT ID,COUNT($wpdb->comments.comment_post_ID) AS 'comment_count' FROM $wpdb->posts, $wpdb->comments WHERE comment_approved = '1' AND $wpdb->posts.ID=$wpdb->comments.comment_post_ID AND post_status = 'publish' GROUP BY $wpdb->comments.comment_post_ID ORDER BY comment_count DESC $limitclause"; 
    return $wpdb->get_results($q);
} 

function eyebo_most_commented_posts ($number = 10){
	$limitclause="LIMIT " . $number;
	$most_commented_posts = eyebo_get_most_commented_posts ($limitclause);
	foreach ($most_commented_posts as $most_commented_post ){
		$output .= '<li>';
		$output .=  '<a href="'.get_permalink($most_commented_post->ID).'" title="'.get_the_title($most_commented_post->ID).'">'.get_the_title($most_commented_post->ID).'</a></li>';
	}
	$output = '<li class="most_commented"><ul><h2>'.__('Most commented posts','eyebo').'</h2>' . $output . '</ul></li>';
	echo $output;
}
function eyebo_widget_meta($args) {
	extract($args);
	$options = get_option('widget_meta');
	$title = empty($options['title']) ? __('Meta') : $options['title'];
	echo $before_widget . $before_title . $title . $after_title;
?>
			<ul>
                <?php wp_register(); ?>
					<li><a href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Transitional', 'eyebo'); ?>"><?php _e('Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr>', 'eyebo'); ?></a></li>
					<li><a href="http://gmpg.org/xfn/"><abbr title="<?php _e('XHTML Friends Network', 'eyebo'); ?>"><?php _e('XFN', 'eyebo'); ?></abbr></a></li>					<li><a href="http://wordpress.org/" title="<?php _e('Powered by WordPress, state-of-the-art semantic personal publishing platform.', 'eyebo'); ?>">WordPress</a></li>
                    <li class="rss"><a href="<?php bloginfo('rss2_url'); ?>">(RSS2.0)</a></li>
				<li class="atom"><a href="<?php bloginfo('atom_url'); ?>">(Atom)</a></li>
					<?php wp_meta(); ?>
			</ul>
<?php
	echo $after_widget;
}
wp_register_sidebar_widget('meta', __('Meta'), 'eyebo_widget_meta');
?>
<?php
//Trackbacks
function custom_pings($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
?>
<li class="<?php echo $oddcomment; ?> bubble" id="comment-<?php comment_ID() ?>">
<blockquote>
  <?php comment_text() ?>
  </blockquote>
  <cite>
  <?php comment_author_link() ?> | <?php comment_date(__('Y-m-d (D)','eyebo')) ?><?php comment_time(__('G:i','eyebo')) ?>
  <?php edit_comment_link(__('Edit','eyebo'),' | ',''); ?>
  </cite>
  <?php if ($comment->comment_approved == '0') : ?>
   <em><?php _e('Your comment is awaiting moderation.', 'eyebo'); ?></em>
  <?php endif; ?>
<?php } ?>
<?php
//comments
function custom_comments($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    global $commentcount;
    if(!$commentcount) $commentcount = 0;
    $commentcount ++;
    global $commentalt;
    ($commentalt == "alt")?$commentalt="":$commentalt="alt";   
?>
<li class="<?php echo $oddcomment; ?> bubble" id="comment-<?php comment_ID() ?>">
  <blockquote>
    <?php comment_text() ?>
  </blockquote>
  <cite><?php if(function_exists('get_avatar')) { echo get_avatar($comment, '32'); } ?>
  <?php comment_author_link() ?> | <?php comment_date(__('Y-m-d (D)','eyebo')) ?> | <?php comment_time(__('G:i','eyebo')) ?>
   | <?php comment_reply_link(array('depth' => $depth, 'max_depth'=> $args['max_depth'], 'reply_text' => __('Reply' , 'eyebo')));?>
  <?php edit_comment_link(__('Edit','eyebo'),' | ',''); ?>
  </cite>
  <?php if ($comment->comment_approved == '0') : ?>
  <em><?php _e('Your comment is awaiting moderation.', 'eyebo'); ?></em>
  <?php endif; ?>
<?php } ?>
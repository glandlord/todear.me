<?php get_header(); ?>

	<div id="content">

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


		<div class="post" id="post-<?php the_ID(); ?>">
			<h2><?php the_title(); ?></h2>
			
			<div class="postmetadata">Posted on <?php the_time(get_option('date_format')) ?>, <?php the_time(get_option('time_format')) ?>, by <?php the_author() ?>, under <?php the_category(', ') ?>.</div>

			<div class="entry">
				<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>

				<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
			</div>

			<div class="postmetadata">
					<?php if( function_exists('the_tags') ) 
						the_tags(__('Tags: '), ', ', '<br />'); 
					?>
					
					<?php if('open' == $post->comment_status) { ?><a href="#respond"><?php _e('Comment') ?></a> (<?php comments_rss_link('RSS'); ?>)<?php } ?>
					<?php if('open' == $post->ping_status) { ?>&nbsp;|&nbsp;&nbsp;<a href="<?php trackback_url(true); ?> " rel="trackback"><?php _e('Trackback') ?></a><?php } ?>
					<?php edit_post_link(__('Edit'), '&nbsp;|&nbsp;&nbsp;', ''); ?>
			 </div>
		</div>
        
        
        
        
 <div id="about">       
        <div style="float:right; width:50%">
			<h3>Most Popular</h3>
			<ul>
			<?php
			$post_num = 5; // 數量設定.
			$exclude_id = $post->ID;
			$myposts = $wpdb->get_results("
  				SELECT ID, post_title FROM $wpdb->posts
  				WHERE ID != $exclude_id
  				AND post_status = 'publish'
  				AND post_type = 'post'
  				ORDER BY comment_count
  				DESC LIMIT $post_num
			"); // get_results() since 0.71 /wp-includes/wp-db.php 
  				foreach($myposts as $mypost) {
    				echo '<li> <a href="', get_permalink($mypost->ID), '">', $mypost->post_title, '</a></li>';
  				$exclude_id .= ',' . $post->ID; // 記錄文章 ID, 讓 Related Posts 不重覆.(單獨使用可刪此行)
  				}
			?>
			</ul>
			</div>

		<div style="float:right; width:45%">
			<h3>Related Posts</h3>
			<ul>
			<?php
			$post_num = 5; // 數量設定.
			//$exclude_id = $post->ID; // 單獨使用要開此行
			global $posttags; $i = 0;
			if ( $posttags ) { $tags = ''; foreach ( $posttags as $tag ) $tags .= $tag->name . ',';
			$args = array(
				'post_status' => 'publish',
				'tag_slug__in' => explode(',', $tags), // 只選 tags 的文章.
				'post__not_in' => explode(',', $exclude_id), // 排除已出現過的文章.
				'caller_get_posts' => 1, // 排除置頂文章.
				'orderby' => 'comment_date', // 依評論日期排序.
				'posts_per_page' => $post_num
			);
			query_posts($args); // query_posts() since 2.0.0 /wp-includes/classes.php
 				while( have_posts() ) { the_post(); ?>
    				<li> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
		<?php
    			$exclude_id .= ',' . $post->ID; $i ++;
 			} wp_reset_query();
		}
		if ( $i < $post_num ) { // 當 tags 文章數量不足, 再取 category 補足.
		$cats = ''; foreach ( get_the_category() as $cat ) $cats .= $cat->cat_ID . ',';
		$args = array(
					'category__in' => explode(',', $cats), // 只選 category 的文章.
					'post__not_in' => explode(',', $exclude_id),
					'caller_get_posts' => 1,
					'orderby' => 'comment_date',
					'posts_per_page' => $post_num - $i
		);
		query_posts($args);
 			while( have_posts() ) { the_post(); ?>
    			<li> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
		<?php
    			$i ++;
 			} wp_reset_query();
		}
		if ( $i  == 0 )  echo '<li>尚無相關文章</li>';
		?>
		</ul>
		</div>

		<div style="clear:both;"></div>
</div>

<?php /*?>只有相关文章，无受欢迎文章<?php */?> 
<?php /*?>
		<div id="about">
        <h3>相关文章：</h3>
			<ul>
			<?php
			$post_num = 5; // 數量設定.
			global $post;
			$tmp_post = $post;
			$tags = ''; $i = 0; // 先取 tags 文章.
			$exclude_id = $post->ID;
			$posttags = get_the_tags();
			if ( $posttags ) {
  			foreach ( $posttags as $tag ) $tags .= $tag->name . ',';
  			$tags = strtr(rtrim($tags, ','), ' ', '-');
  			$myposts = get_posts('numberposts='.$post_num.'&tag='.$tags.'&exclude='.$exclude_id);
  			foreach($myposts as $post) {
    		setup_postdata($post);
    		?>
    			<li>&#9829; <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> (<?php comments_number(); ?>)</li>
    			<?php
    			$exclude_id .= ','.$post->ID; $i ++;
  					}
				}
					if ( $i < $post_num ) { // 當 tags 文章數量不足, 再取 category 補足.
  						$post = $tmp_post; setup_postdata($post);
  						$cats = ''; $post_num -= $i;
  						foreach ( get_the_category() as $cat ) $cats .= $cat->cat_ID . ',';
  						$cats = strtr(rtrim($cats, ','), ' ', '-');
  						$myposts = get_posts('numberposts='.$post_num.'&category='.$cats.'&exclude='.$exclude_id);
  						foreach($myposts as $post) {
    						setup_postdata($post);
    			?>
    			<li>&#9829; <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> (<?php comments_number(); ?>)</li>
    			<?php
  					}
				}
				if ( $i == 0 ) echo '<li>无相关文章</li>';
				$post = $tmp_post; setup_postdata($post);
				?>
				</ul>
            </div>

<?php */?>

	<?php comments_template(); ?>

	<?php endwhile; ?>
		<div class="navigation">
			<div style="text-align:left;"><?php previous_post_link('&laquo; %link') ?></div>
			<div style="text-align:right;"><?php next_post_link('%link &raquo;') ?></div>
		</div>
		
	

	<?php else: ?>

		<p>Sorry, no posts matched your criteria.</p>

<?php endif; ?>

	</div>
	
<?php get_sidebar(); ?>

<?php get_footer(); ?>

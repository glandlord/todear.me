<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />

<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

<?php wp_head(); ?>
</head>
<body>

<!-- clouds -->
<div id="clouds">

<!-- add welcome title -->
<?php if($_COOKIE["comment_author_" . COOKIEHASH]!=""): ?>
<script type="text/javascript">
document.title = "<?php printf(__('Welcome back %s ! '),$_COOKIE ["comment_author_" . COOKIEHASH]) ?>" + document.title
</script>
<?php endif; ?>
<div id="page">


<div id="header">
	<div id="headerimage">
		<h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
		<div class="description"><?php bloginfo('description'); ?></div>
	</div>
</div>

<div id="hmenu">
<ul>
	<li><a href="<?php echo get_settings('home'); ?>"><?php _e('Home') ?></a></li>
	<?php wp_list_pages('title_li=&depth=1') ?>
	<li id="hmenu_rss">	<a href="<?php bloginfo('rss2_url'); ?>"  title="<?php bloginfo('name'); ?> RSS Feed">Subscribe to Feed</a></li>

</ul>
</div>
<hr />


<!-- add huadong daohang -->
<?php if (is_home()) { ?>
<div id="shangxia"><div id="shang"></div><div id="xia"></div></div>
<?php } else { ?>
<div id="shangxia"><div id="shang"></div><div id="comt"></div><div id="xia"></div></div>
<?php } ?>

<div id="wrapper">

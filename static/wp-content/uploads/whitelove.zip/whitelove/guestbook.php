<?php
/*
Template Name: guestbook
*/
?>
<?php get_header(); ?>

	<div id="content">

		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
		<h2><?php the_title(); ?></h2>
        
           
                    <!-- start 读者墙 -->

<?php
    $query="SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 1 YEAR ) AND user_id='0' AND comment_author_email != 'blueandhack@gmail.com' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 72";
    $wall = $wpdb->get_results($query);
    foreach ($wall as $comment)
    {
        if( $comment->comment_author_url )
        $url = $comment->comment_author_url;
        else $url="#";
        $tmp = "<a href='".$url."' title='".$comment->comment_author." (".$comment->cnt.")'>".get_avatar($comment->comment_author_email, 40)."</a>";
        $output .= $tmp;
     }
    $output = "<div id='readerswall'>".$output."</div>";
    echo $output ;
?>
<!-- end 读者墙 -->




			<div class="entry">
            
 
				<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>

				<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>

			</div>
			<div class="postmetadata">
				<?php if( function_exists('the_tags') ) 
					the_tags(__('Tags: '), ', ', '<br />'); 
				?>
			
				<?php if('open' == $post->comment_status) { ?><a href="#respond"><?php _e('Comment') ?></a> (<?php comments_rss_link('RSS'); ?>)<?php } ?>
				<?php if('open' == $post->ping_status) { ?>&nbsp;|&nbsp;&nbsp;<a href="<?php trackback_url(true); ?> " rel="trackback"><?php _e('Trackback') ?></a><?php } ?>
				<?php edit_post_link(__('Edit'), '&nbsp;|&nbsp;&nbsp;', ''); ?>
			 </div>
		</div>
	<?php comments_template(); ?>
		<?php endwhile; endif; ?>
	
	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>

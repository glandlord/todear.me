WhiteLove WordPress theme version 1.0.0

Visit http://blueandhack.com/themes/1202.html for updates.

Features
* Fixed width
* Two columns
* Right sidebar
* Minimalist -- simple -- clean -- plain -- white -- blue
* Supports comments threading (WP 3.0), comments paging (WP 3.0), gravatars in comments, post tags and sidebar widgets.
* Valid XHTML and CSS

Installation:
* Extract the plainscape.zip file in a convenient location
* Copy the 'plainscape' folder to '/wp-content/themes/' directory in your web server.
* Log in to the WordPress Administration Panels
* Select the 'Themes' sub-menu from 'Appearance' menu (or 'Design'/'Presentation' depending on the WP version you are using).
* Select the WhiteLove theme from the available list of themes to preview
* Activate the theme.
* Your selection should now become active.

The theme is released under GPL (http://www.opensource.org/licenses/gpl-license.php).

All feedback, bug reports, feature requests to blueandhack@gmail.com or as comments at the theme page at http://blueandhack.com/themes/1202.html

----
http://blueandhack.com


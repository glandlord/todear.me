<hr />


</div>

<div id="footer">

	<p>

		Powered by
		<a href="http://wordpress.org/">WordPress</a> and <a href="http://blueandhack.com">blueandhack</a> theme.<br />
		<br /><?php wp_footer(); ?>
	

		

		<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
	</p>
</div>


		
</div>

<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/jquery.lazyload.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/all.js"></script>
<?php if ( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<?php } ?>


</div>
<!-- clouds end -->



</body>
</html>